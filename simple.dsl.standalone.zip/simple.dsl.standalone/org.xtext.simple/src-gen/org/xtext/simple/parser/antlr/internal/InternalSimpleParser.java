package org.xtext.simple.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.simple.services.SimpleGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSimpleParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'package'", "'{'", "'}'", "'class'", "';'", "'public'", "'private'", "'String'", "'float'", "'integer'", "'mandatory'", "'optional'", "'multivalued'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=6;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalSimpleParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSimpleParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSimpleParser.tokenNames; }
    public String getGrammarFileName() { return "InternalSimple.g"; }



     	private SimpleGrammarAccess grammarAccess;

        public InternalSimpleParser(TokenStream input, SimpleGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Program";
       	}

       	@Override
       	protected SimpleGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleProgram"
    // InternalSimple.g:65:1: entryRuleProgram returns [EObject current=null] : iv_ruleProgram= ruleProgram EOF ;
    public final EObject entryRuleProgram() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProgram = null;


        try {
            // InternalSimple.g:65:48: (iv_ruleProgram= ruleProgram EOF )
            // InternalSimple.g:66:2: iv_ruleProgram= ruleProgram EOF
            {
             newCompositeNode(grammarAccess.getProgramRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProgram=ruleProgram();

            state._fsp--;

             current =iv_ruleProgram; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProgram"


    // $ANTLR start "ruleProgram"
    // InternalSimple.g:72:1: ruleProgram returns [EObject current=null] : ( () ( (lv_packages_1_0= rulePackage ) )+ ) ;
    public final EObject ruleProgram() throws RecognitionException {
        EObject current = null;

        EObject lv_packages_1_0 = null;



        	enterRule();

        try {
            // InternalSimple.g:78:2: ( ( () ( (lv_packages_1_0= rulePackage ) )+ ) )
            // InternalSimple.g:79:2: ( () ( (lv_packages_1_0= rulePackage ) )+ )
            {
            // InternalSimple.g:79:2: ( () ( (lv_packages_1_0= rulePackage ) )+ )
            // InternalSimple.g:80:3: () ( (lv_packages_1_0= rulePackage ) )+
            {
            // InternalSimple.g:80:3: ()
            // InternalSimple.g:81:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getProgramAccess().getProgramAction_0(),
            					current);
            			

            }

            // InternalSimple.g:87:3: ( (lv_packages_1_0= rulePackage ) )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSimple.g:88:4: (lv_packages_1_0= rulePackage )
            	    {
            	    // InternalSimple.g:88:4: (lv_packages_1_0= rulePackage )
            	    // InternalSimple.g:89:5: lv_packages_1_0= rulePackage
            	    {

            	    					newCompositeNode(grammarAccess.getProgramAccess().getPackagesPackageParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_3);
            	    lv_packages_1_0=rulePackage();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getProgramRule());
            	    					}
            	    					add(
            	    						current,
            	    						"packages",
            	    						lv_packages_1_0,
            	    						"org.xtext.simple.Simple.Package");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProgram"


    // $ANTLR start "entryRulePackage"
    // InternalSimple.g:110:1: entryRulePackage returns [EObject current=null] : iv_rulePackage= rulePackage EOF ;
    public final EObject entryRulePackage() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePackage = null;


        try {
            // InternalSimple.g:110:48: (iv_rulePackage= rulePackage EOF )
            // InternalSimple.g:111:2: iv_rulePackage= rulePackage EOF
            {
             newCompositeNode(grammarAccess.getPackageRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePackage=rulePackage();

            state._fsp--;

             current =iv_rulePackage; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePackage"


    // $ANTLR start "rulePackage"
    // InternalSimple.g:117:1: rulePackage returns [EObject current=null] : ( () otherlv_1= 'package' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' ( ( (lv_packages_4_0= rulePackage ) ) | ( (lv_classes_5_0= ruleClass ) ) )* otherlv_6= '}' ) ;
    public final EObject rulePackage() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_6=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        EObject lv_packages_4_0 = null;

        EObject lv_classes_5_0 = null;



        	enterRule();

        try {
            // InternalSimple.g:123:2: ( ( () otherlv_1= 'package' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' ( ( (lv_packages_4_0= rulePackage ) ) | ( (lv_classes_5_0= ruleClass ) ) )* otherlv_6= '}' ) )
            // InternalSimple.g:124:2: ( () otherlv_1= 'package' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' ( ( (lv_packages_4_0= rulePackage ) ) | ( (lv_classes_5_0= ruleClass ) ) )* otherlv_6= '}' )
            {
            // InternalSimple.g:124:2: ( () otherlv_1= 'package' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' ( ( (lv_packages_4_0= rulePackage ) ) | ( (lv_classes_5_0= ruleClass ) ) )* otherlv_6= '}' )
            // InternalSimple.g:125:3: () otherlv_1= 'package' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' ( ( (lv_packages_4_0= rulePackage ) ) | ( (lv_classes_5_0= ruleClass ) ) )* otherlv_6= '}'
            {
            // InternalSimple.g:125:3: ()
            // InternalSimple.g:126:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getPackageAccess().getPackageAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,11,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getPackageAccess().getPackageKeyword_1());
            		
            // InternalSimple.g:136:3: ( (lv_name_2_0= ruleEString ) )
            // InternalSimple.g:137:4: (lv_name_2_0= ruleEString )
            {
            // InternalSimple.g:137:4: (lv_name_2_0= ruleEString )
            // InternalSimple.g:138:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getPackageAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPackageRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.xtext.simple.Simple.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_3, grammarAccess.getPackageAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalSimple.g:159:3: ( ( (lv_packages_4_0= rulePackage ) ) | ( (lv_classes_5_0= ruleClass ) ) )*
            loop2:
            do {
                int alt2=3;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==11) ) {
                    alt2=1;
                }
                else if ( (LA2_0==14||(LA2_0>=16 && LA2_0<=17)) ) {
                    alt2=2;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSimple.g:160:4: ( (lv_packages_4_0= rulePackage ) )
            	    {
            	    // InternalSimple.g:160:4: ( (lv_packages_4_0= rulePackage ) )
            	    // InternalSimple.g:161:5: (lv_packages_4_0= rulePackage )
            	    {
            	    // InternalSimple.g:161:5: (lv_packages_4_0= rulePackage )
            	    // InternalSimple.g:162:6: lv_packages_4_0= rulePackage
            	    {

            	    						newCompositeNode(grammarAccess.getPackageAccess().getPackagesPackageParserRuleCall_4_0_0());
            	    					
            	    pushFollow(FOLLOW_6);
            	    lv_packages_4_0=rulePackage();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getPackageRule());
            	    						}
            	    						add(
            	    							current,
            	    							"packages",
            	    							lv_packages_4_0,
            	    							"org.xtext.simple.Simple.Package");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // InternalSimple.g:180:4: ( (lv_classes_5_0= ruleClass ) )
            	    {
            	    // InternalSimple.g:180:4: ( (lv_classes_5_0= ruleClass ) )
            	    // InternalSimple.g:181:5: (lv_classes_5_0= ruleClass )
            	    {
            	    // InternalSimple.g:181:5: (lv_classes_5_0= ruleClass )
            	    // InternalSimple.g:182:6: lv_classes_5_0= ruleClass
            	    {

            	    						newCompositeNode(grammarAccess.getPackageAccess().getClassesClassParserRuleCall_4_1_0());
            	    					
            	    pushFollow(FOLLOW_6);
            	    lv_classes_5_0=ruleClass();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getPackageRule());
            	    						}
            	    						add(
            	    							current,
            	    							"classes",
            	    							lv_classes_5_0,
            	    							"org.xtext.simple.Simple.Class");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            otherlv_6=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getPackageAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePackage"


    // $ANTLR start "entryRuleEString"
    // InternalSimple.g:208:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalSimple.g:208:47: (iv_ruleEString= ruleEString EOF )
            // InternalSimple.g:209:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalSimple.g:215:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalSimple.g:221:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalSimple.g:222:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalSimple.g:222:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==RULE_STRING) ) {
                alt3=1;
            }
            else if ( (LA3_0==RULE_ID) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalSimple.g:223:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSimple.g:231:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleClass"
    // InternalSimple.g:242:1: entryRuleClass returns [EObject current=null] : iv_ruleClass= ruleClass EOF ;
    public final EObject entryRuleClass() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClass = null;


        try {
            // InternalSimple.g:242:46: (iv_ruleClass= ruleClass EOF )
            // InternalSimple.g:243:2: iv_ruleClass= ruleClass EOF
            {
             newCompositeNode(grammarAccess.getClassRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleClass=ruleClass();

            state._fsp--;

             current =iv_ruleClass; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClass"


    // $ANTLR start "ruleClass"
    // InternalSimple.g:249:1: ruleClass returns [EObject current=null] : ( () ( (lv_visibility_1_0= ruleVisibility ) )? otherlv_2= 'class' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' ( ( ( (lv_attributes_5_0= ruleAttribute ) ) | ( (lv_references_6_0= ruleReference ) ) ) otherlv_7= ';' ( ( ( (lv_attributes_8_0= ruleAttribute ) ) | ( (lv_references_9_0= ruleReference ) ) ) otherlv_10= ';' )* )? otherlv_11= '}' ) ;
    public final EObject ruleClass() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_7=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Enumerator lv_visibility_1_0 = null;

        AntlrDatatypeRuleToken lv_name_3_0 = null;

        EObject lv_attributes_5_0 = null;

        EObject lv_references_6_0 = null;

        EObject lv_attributes_8_0 = null;

        EObject lv_references_9_0 = null;



        	enterRule();

        try {
            // InternalSimple.g:255:2: ( ( () ( (lv_visibility_1_0= ruleVisibility ) )? otherlv_2= 'class' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' ( ( ( (lv_attributes_5_0= ruleAttribute ) ) | ( (lv_references_6_0= ruleReference ) ) ) otherlv_7= ';' ( ( ( (lv_attributes_8_0= ruleAttribute ) ) | ( (lv_references_9_0= ruleReference ) ) ) otherlv_10= ';' )* )? otherlv_11= '}' ) )
            // InternalSimple.g:256:2: ( () ( (lv_visibility_1_0= ruleVisibility ) )? otherlv_2= 'class' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' ( ( ( (lv_attributes_5_0= ruleAttribute ) ) | ( (lv_references_6_0= ruleReference ) ) ) otherlv_7= ';' ( ( ( (lv_attributes_8_0= ruleAttribute ) ) | ( (lv_references_9_0= ruleReference ) ) ) otherlv_10= ';' )* )? otherlv_11= '}' )
            {
            // InternalSimple.g:256:2: ( () ( (lv_visibility_1_0= ruleVisibility ) )? otherlv_2= 'class' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' ( ( ( (lv_attributes_5_0= ruleAttribute ) ) | ( (lv_references_6_0= ruleReference ) ) ) otherlv_7= ';' ( ( ( (lv_attributes_8_0= ruleAttribute ) ) | ( (lv_references_9_0= ruleReference ) ) ) otherlv_10= ';' )* )? otherlv_11= '}' )
            // InternalSimple.g:257:3: () ( (lv_visibility_1_0= ruleVisibility ) )? otherlv_2= 'class' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' ( ( ( (lv_attributes_5_0= ruleAttribute ) ) | ( (lv_references_6_0= ruleReference ) ) ) otherlv_7= ';' ( ( ( (lv_attributes_8_0= ruleAttribute ) ) | ( (lv_references_9_0= ruleReference ) ) ) otherlv_10= ';' )* )? otherlv_11= '}'
            {
            // InternalSimple.g:257:3: ()
            // InternalSimple.g:258:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getClassAccess().getClassAction_0(),
            					current);
            			

            }

            // InternalSimple.g:264:3: ( (lv_visibility_1_0= ruleVisibility ) )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( ((LA4_0>=16 && LA4_0<=17)) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalSimple.g:265:4: (lv_visibility_1_0= ruleVisibility )
                    {
                    // InternalSimple.g:265:4: (lv_visibility_1_0= ruleVisibility )
                    // InternalSimple.g:266:5: lv_visibility_1_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getClassAccess().getVisibilityVisibilityEnumRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_7);
                    lv_visibility_1_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClassRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_1_0,
                    						"org.xtext.simple.Simple.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            otherlv_2=(Token)match(input,14,FOLLOW_4); 

            			newLeafNode(otherlv_2, grammarAccess.getClassAccess().getClassKeyword_2());
            		
            // InternalSimple.g:287:3: ( (lv_name_3_0= ruleEString ) )
            // InternalSimple.g:288:4: (lv_name_3_0= ruleEString )
            {
            // InternalSimple.g:288:4: (lv_name_3_0= ruleEString )
            // InternalSimple.g:289:5: lv_name_3_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getClassAccess().getNameEStringParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_3_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClassRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_3_0,
            						"org.xtext.simple.Simple.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,12,FOLLOW_8); 

            			newLeafNode(otherlv_4, grammarAccess.getClassAccess().getLeftCurlyBracketKeyword_4());
            		
            // InternalSimple.g:310:3: ( ( ( (lv_attributes_5_0= ruleAttribute ) ) | ( (lv_references_6_0= ruleReference ) ) ) otherlv_7= ';' ( ( ( (lv_attributes_8_0= ruleAttribute ) ) | ( (lv_references_9_0= ruleReference ) ) ) otherlv_10= ';' )* )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( ((LA8_0>=16 && LA8_0<=17)||(LA8_0>=21 && LA8_0<=23)) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalSimple.g:311:4: ( ( (lv_attributes_5_0= ruleAttribute ) ) | ( (lv_references_6_0= ruleReference ) ) ) otherlv_7= ';' ( ( ( (lv_attributes_8_0= ruleAttribute ) ) | ( (lv_references_9_0= ruleReference ) ) ) otherlv_10= ';' )*
                    {
                    // InternalSimple.g:311:4: ( ( (lv_attributes_5_0= ruleAttribute ) ) | ( (lv_references_6_0= ruleReference ) ) )
                    int alt5=2;
                    switch ( input.LA(1) ) {
                    case 16:
                        {
                        switch ( input.LA(2) ) {
                        case 21:
                            {
                            int LA5_3 = input.LA(3);

                            if ( (LA5_3==RULE_ID) ) {
                                alt5=2;
                            }
                            else if ( ((LA5_3>=18 && LA5_3<=20)) ) {
                                alt5=1;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 5, 3, input);

                                throw nvae;
                            }
                            }
                            break;
                        case 22:
                            {
                            int LA5_4 = input.LA(3);

                            if ( (LA5_4==RULE_ID) ) {
                                alt5=2;
                            }
                            else if ( ((LA5_4>=18 && LA5_4<=20)) ) {
                                alt5=1;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 5, 4, input);

                                throw nvae;
                            }
                            }
                            break;
                        case 23:
                            {
                            int LA5_5 = input.LA(3);

                            if ( (LA5_5==RULE_ID) ) {
                                alt5=2;
                            }
                            else if ( ((LA5_5>=18 && LA5_5<=20)) ) {
                                alt5=1;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 5, 5, input);

                                throw nvae;
                            }
                            }
                            break;
                        default:
                            NoViableAltException nvae =
                                new NoViableAltException("", 5, 1, input);

                            throw nvae;
                        }

                        }
                        break;
                    case 17:
                        {
                        switch ( input.LA(2) ) {
                        case 21:
                            {
                            int LA5_3 = input.LA(3);

                            if ( (LA5_3==RULE_ID) ) {
                                alt5=2;
                            }
                            else if ( ((LA5_3>=18 && LA5_3<=20)) ) {
                                alt5=1;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 5, 3, input);

                                throw nvae;
                            }
                            }
                            break;
                        case 22:
                            {
                            int LA5_4 = input.LA(3);

                            if ( (LA5_4==RULE_ID) ) {
                                alt5=2;
                            }
                            else if ( ((LA5_4>=18 && LA5_4<=20)) ) {
                                alt5=1;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 5, 4, input);

                                throw nvae;
                            }
                            }
                            break;
                        case 23:
                            {
                            int LA5_5 = input.LA(3);

                            if ( (LA5_5==RULE_ID) ) {
                                alt5=2;
                            }
                            else if ( ((LA5_5>=18 && LA5_5<=20)) ) {
                                alt5=1;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 5, 5, input);

                                throw nvae;
                            }
                            }
                            break;
                        default:
                            NoViableAltException nvae =
                                new NoViableAltException("", 5, 2, input);

                            throw nvae;
                        }

                        }
                        break;
                    case 21:
                        {
                        int LA5_3 = input.LA(2);

                        if ( (LA5_3==RULE_ID) ) {
                            alt5=2;
                        }
                        else if ( ((LA5_3>=18 && LA5_3<=20)) ) {
                            alt5=1;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 5, 3, input);

                            throw nvae;
                        }
                        }
                        break;
                    case 22:
                        {
                        int LA5_4 = input.LA(2);

                        if ( (LA5_4==RULE_ID) ) {
                            alt5=2;
                        }
                        else if ( ((LA5_4>=18 && LA5_4<=20)) ) {
                            alt5=1;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 5, 4, input);

                            throw nvae;
                        }
                        }
                        break;
                    case 23:
                        {
                        int LA5_5 = input.LA(2);

                        if ( (LA5_5==RULE_ID) ) {
                            alt5=2;
                        }
                        else if ( ((LA5_5>=18 && LA5_5<=20)) ) {
                            alt5=1;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 5, 5, input);

                            throw nvae;
                        }
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 5, 0, input);

                        throw nvae;
                    }

                    switch (alt5) {
                        case 1 :
                            // InternalSimple.g:312:5: ( (lv_attributes_5_0= ruleAttribute ) )
                            {
                            // InternalSimple.g:312:5: ( (lv_attributes_5_0= ruleAttribute ) )
                            // InternalSimple.g:313:6: (lv_attributes_5_0= ruleAttribute )
                            {
                            // InternalSimple.g:313:6: (lv_attributes_5_0= ruleAttribute )
                            // InternalSimple.g:314:7: lv_attributes_5_0= ruleAttribute
                            {

                            							newCompositeNode(grammarAccess.getClassAccess().getAttributesAttributeParserRuleCall_5_0_0_0());
                            						
                            pushFollow(FOLLOW_9);
                            lv_attributes_5_0=ruleAttribute();

                            state._fsp--;


                            							if (current==null) {
                            								current = createModelElementForParent(grammarAccess.getClassRule());
                            							}
                            							add(
                            								current,
                            								"attributes",
                            								lv_attributes_5_0,
                            								"org.xtext.simple.Simple.Attribute");
                            							afterParserOrEnumRuleCall();
                            						

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSimple.g:332:5: ( (lv_references_6_0= ruleReference ) )
                            {
                            // InternalSimple.g:332:5: ( (lv_references_6_0= ruleReference ) )
                            // InternalSimple.g:333:6: (lv_references_6_0= ruleReference )
                            {
                            // InternalSimple.g:333:6: (lv_references_6_0= ruleReference )
                            // InternalSimple.g:334:7: lv_references_6_0= ruleReference
                            {

                            							newCompositeNode(grammarAccess.getClassAccess().getReferencesReferenceParserRuleCall_5_0_1_0());
                            						
                            pushFollow(FOLLOW_9);
                            lv_references_6_0=ruleReference();

                            state._fsp--;


                            							if (current==null) {
                            								current = createModelElementForParent(grammarAccess.getClassRule());
                            							}
                            							add(
                            								current,
                            								"references",
                            								lv_references_6_0,
                            								"org.xtext.simple.Simple.Reference");
                            							afterParserOrEnumRuleCall();
                            						

                            }


                            }


                            }
                            break;

                    }

                    otherlv_7=(Token)match(input,15,FOLLOW_8); 

                    				newLeafNode(otherlv_7, grammarAccess.getClassAccess().getSemicolonKeyword_5_1());
                    			
                    // InternalSimple.g:356:4: ( ( ( (lv_attributes_8_0= ruleAttribute ) ) | ( (lv_references_9_0= ruleReference ) ) ) otherlv_10= ';' )*
                    loop7:
                    do {
                        int alt7=2;
                        int LA7_0 = input.LA(1);

                        if ( ((LA7_0>=16 && LA7_0<=17)||(LA7_0>=21 && LA7_0<=23)) ) {
                            alt7=1;
                        }


                        switch (alt7) {
                    	case 1 :
                    	    // InternalSimple.g:357:5: ( ( (lv_attributes_8_0= ruleAttribute ) ) | ( (lv_references_9_0= ruleReference ) ) ) otherlv_10= ';'
                    	    {
                    	    // InternalSimple.g:357:5: ( ( (lv_attributes_8_0= ruleAttribute ) ) | ( (lv_references_9_0= ruleReference ) ) )
                    	    int alt6=2;
                    	    switch ( input.LA(1) ) {
                    	    case 16:
                    	        {
                    	        switch ( input.LA(2) ) {
                    	        case 21:
                    	            {
                    	            int LA6_3 = input.LA(3);

                    	            if ( (LA6_3==RULE_ID) ) {
                    	                alt6=2;
                    	            }
                    	            else if ( ((LA6_3>=18 && LA6_3<=20)) ) {
                    	                alt6=1;
                    	            }
                    	            else {
                    	                NoViableAltException nvae =
                    	                    new NoViableAltException("", 6, 3, input);

                    	                throw nvae;
                    	            }
                    	            }
                    	            break;
                    	        case 22:
                    	            {
                    	            int LA6_4 = input.LA(3);

                    	            if ( ((LA6_4>=18 && LA6_4<=20)) ) {
                    	                alt6=1;
                    	            }
                    	            else if ( (LA6_4==RULE_ID) ) {
                    	                alt6=2;
                    	            }
                    	            else {
                    	                NoViableAltException nvae =
                    	                    new NoViableAltException("", 6, 4, input);

                    	                throw nvae;
                    	            }
                    	            }
                    	            break;
                    	        case 23:
                    	            {
                    	            int LA6_5 = input.LA(3);

                    	            if ( (LA6_5==RULE_ID) ) {
                    	                alt6=2;
                    	            }
                    	            else if ( ((LA6_5>=18 && LA6_5<=20)) ) {
                    	                alt6=1;
                    	            }
                    	            else {
                    	                NoViableAltException nvae =
                    	                    new NoViableAltException("", 6, 5, input);

                    	                throw nvae;
                    	            }
                    	            }
                    	            break;
                    	        default:
                    	            NoViableAltException nvae =
                    	                new NoViableAltException("", 6, 1, input);

                    	            throw nvae;
                    	        }

                    	        }
                    	        break;
                    	    case 17:
                    	        {
                    	        switch ( input.LA(2) ) {
                    	        case 21:
                    	            {
                    	            int LA6_3 = input.LA(3);

                    	            if ( (LA6_3==RULE_ID) ) {
                    	                alt6=2;
                    	            }
                    	            else if ( ((LA6_3>=18 && LA6_3<=20)) ) {
                    	                alt6=1;
                    	            }
                    	            else {
                    	                NoViableAltException nvae =
                    	                    new NoViableAltException("", 6, 3, input);

                    	                throw nvae;
                    	            }
                    	            }
                    	            break;
                    	        case 22:
                    	            {
                    	            int LA6_4 = input.LA(3);

                    	            if ( ((LA6_4>=18 && LA6_4<=20)) ) {
                    	                alt6=1;
                    	            }
                    	            else if ( (LA6_4==RULE_ID) ) {
                    	                alt6=2;
                    	            }
                    	            else {
                    	                NoViableAltException nvae =
                    	                    new NoViableAltException("", 6, 4, input);

                    	                throw nvae;
                    	            }
                    	            }
                    	            break;
                    	        case 23:
                    	            {
                    	            int LA6_5 = input.LA(3);

                    	            if ( (LA6_5==RULE_ID) ) {
                    	                alt6=2;
                    	            }
                    	            else if ( ((LA6_5>=18 && LA6_5<=20)) ) {
                    	                alt6=1;
                    	            }
                    	            else {
                    	                NoViableAltException nvae =
                    	                    new NoViableAltException("", 6, 5, input);

                    	                throw nvae;
                    	            }
                    	            }
                    	            break;
                    	        default:
                    	            NoViableAltException nvae =
                    	                new NoViableAltException("", 6, 2, input);

                    	            throw nvae;
                    	        }

                    	        }
                    	        break;
                    	    case 21:
                    	        {
                    	        int LA6_3 = input.LA(2);

                    	        if ( (LA6_3==RULE_ID) ) {
                    	            alt6=2;
                    	        }
                    	        else if ( ((LA6_3>=18 && LA6_3<=20)) ) {
                    	            alt6=1;
                    	        }
                    	        else {
                    	            NoViableAltException nvae =
                    	                new NoViableAltException("", 6, 3, input);

                    	            throw nvae;
                    	        }
                    	        }
                    	        break;
                    	    case 22:
                    	        {
                    	        int LA6_4 = input.LA(2);

                    	        if ( ((LA6_4>=18 && LA6_4<=20)) ) {
                    	            alt6=1;
                    	        }
                    	        else if ( (LA6_4==RULE_ID) ) {
                    	            alt6=2;
                    	        }
                    	        else {
                    	            NoViableAltException nvae =
                    	                new NoViableAltException("", 6, 4, input);

                    	            throw nvae;
                    	        }
                    	        }
                    	        break;
                    	    case 23:
                    	        {
                    	        int LA6_5 = input.LA(2);

                    	        if ( (LA6_5==RULE_ID) ) {
                    	            alt6=2;
                    	        }
                    	        else if ( ((LA6_5>=18 && LA6_5<=20)) ) {
                    	            alt6=1;
                    	        }
                    	        else {
                    	            NoViableAltException nvae =
                    	                new NoViableAltException("", 6, 5, input);

                    	            throw nvae;
                    	        }
                    	        }
                    	        break;
                    	    default:
                    	        NoViableAltException nvae =
                    	            new NoViableAltException("", 6, 0, input);

                    	        throw nvae;
                    	    }

                    	    switch (alt6) {
                    	        case 1 :
                    	            // InternalSimple.g:358:6: ( (lv_attributes_8_0= ruleAttribute ) )
                    	            {
                    	            // InternalSimple.g:358:6: ( (lv_attributes_8_0= ruleAttribute ) )
                    	            // InternalSimple.g:359:7: (lv_attributes_8_0= ruleAttribute )
                    	            {
                    	            // InternalSimple.g:359:7: (lv_attributes_8_0= ruleAttribute )
                    	            // InternalSimple.g:360:8: lv_attributes_8_0= ruleAttribute
                    	            {

                    	            								newCompositeNode(grammarAccess.getClassAccess().getAttributesAttributeParserRuleCall_5_2_0_0_0());
                    	            							
                    	            pushFollow(FOLLOW_9);
                    	            lv_attributes_8_0=ruleAttribute();

                    	            state._fsp--;


                    	            								if (current==null) {
                    	            									current = createModelElementForParent(grammarAccess.getClassRule());
                    	            								}
                    	            								add(
                    	            									current,
                    	            									"attributes",
                    	            									lv_attributes_8_0,
                    	            									"org.xtext.simple.Simple.Attribute");
                    	            								afterParserOrEnumRuleCall();
                    	            							

                    	            }


                    	            }


                    	            }
                    	            break;
                    	        case 2 :
                    	            // InternalSimple.g:378:6: ( (lv_references_9_0= ruleReference ) )
                    	            {
                    	            // InternalSimple.g:378:6: ( (lv_references_9_0= ruleReference ) )
                    	            // InternalSimple.g:379:7: (lv_references_9_0= ruleReference )
                    	            {
                    	            // InternalSimple.g:379:7: (lv_references_9_0= ruleReference )
                    	            // InternalSimple.g:380:8: lv_references_9_0= ruleReference
                    	            {

                    	            								newCompositeNode(grammarAccess.getClassAccess().getReferencesReferenceParserRuleCall_5_2_0_1_0());
                    	            							
                    	            pushFollow(FOLLOW_9);
                    	            lv_references_9_0=ruleReference();

                    	            state._fsp--;


                    	            								if (current==null) {
                    	            									current = createModelElementForParent(grammarAccess.getClassRule());
                    	            								}
                    	            								add(
                    	            									current,
                    	            									"references",
                    	            									lv_references_9_0,
                    	            									"org.xtext.simple.Simple.Reference");
                    	            								afterParserOrEnumRuleCall();
                    	            							

                    	            }


                    	            }


                    	            }
                    	            break;

                    	    }

                    	    otherlv_10=(Token)match(input,15,FOLLOW_8); 

                    	    					newLeafNode(otherlv_10, grammarAccess.getClassAccess().getSemicolonKeyword_5_2_1());
                    	    				

                    	    }
                    	    break;

                    	default :
                    	    break loop7;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_11=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_11, grammarAccess.getClassAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClass"


    // $ANTLR start "entryRuleAttribute"
    // InternalSimple.g:412:1: entryRuleAttribute returns [EObject current=null] : iv_ruleAttribute= ruleAttribute EOF ;
    public final EObject entryRuleAttribute() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttribute = null;


        try {
            // InternalSimple.g:412:50: (iv_ruleAttribute= ruleAttribute EOF )
            // InternalSimple.g:413:2: iv_ruleAttribute= ruleAttribute EOF
            {
             newCompositeNode(grammarAccess.getAttributeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAttribute=ruleAttribute();

            state._fsp--;

             current =iv_ruleAttribute; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttribute"


    // $ANTLR start "ruleAttribute"
    // InternalSimple.g:419:1: ruleAttribute returns [EObject current=null] : ( () ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_cardinality_2_0= ruleCardinality ) ) ( (lv_type_3_0= ruleType ) ) ( (lv_name_4_0= ruleEString ) ) ) ;
    public final EObject ruleAttribute() throws RecognitionException {
        EObject current = null;

        Enumerator lv_visibility_1_0 = null;

        Enumerator lv_cardinality_2_0 = null;

        Enumerator lv_type_3_0 = null;

        AntlrDatatypeRuleToken lv_name_4_0 = null;



        	enterRule();

        try {
            // InternalSimple.g:425:2: ( ( () ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_cardinality_2_0= ruleCardinality ) ) ( (lv_type_3_0= ruleType ) ) ( (lv_name_4_0= ruleEString ) ) ) )
            // InternalSimple.g:426:2: ( () ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_cardinality_2_0= ruleCardinality ) ) ( (lv_type_3_0= ruleType ) ) ( (lv_name_4_0= ruleEString ) ) )
            {
            // InternalSimple.g:426:2: ( () ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_cardinality_2_0= ruleCardinality ) ) ( (lv_type_3_0= ruleType ) ) ( (lv_name_4_0= ruleEString ) ) )
            // InternalSimple.g:427:3: () ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_cardinality_2_0= ruleCardinality ) ) ( (lv_type_3_0= ruleType ) ) ( (lv_name_4_0= ruleEString ) )
            {
            // InternalSimple.g:427:3: ()
            // InternalSimple.g:428:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getAttributeAccess().getAttributeAction_0(),
            					current);
            			

            }

            // InternalSimple.g:434:3: ( (lv_visibility_1_0= ruleVisibility ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( ((LA9_0>=16 && LA9_0<=17)) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalSimple.g:435:4: (lv_visibility_1_0= ruleVisibility )
                    {
                    // InternalSimple.g:435:4: (lv_visibility_1_0= ruleVisibility )
                    // InternalSimple.g:436:5: lv_visibility_1_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getAttributeAccess().getVisibilityVisibilityEnumRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_10);
                    lv_visibility_1_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getAttributeRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_1_0,
                    						"org.xtext.simple.Simple.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSimple.g:453:3: ( (lv_cardinality_2_0= ruleCardinality ) )
            // InternalSimple.g:454:4: (lv_cardinality_2_0= ruleCardinality )
            {
            // InternalSimple.g:454:4: (lv_cardinality_2_0= ruleCardinality )
            // InternalSimple.g:455:5: lv_cardinality_2_0= ruleCardinality
            {

            					newCompositeNode(grammarAccess.getAttributeAccess().getCardinalityCardinalityEnumRuleCall_2_0());
            				
            pushFollow(FOLLOW_11);
            lv_cardinality_2_0=ruleCardinality();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAttributeRule());
            					}
            					set(
            						current,
            						"cardinality",
            						lv_cardinality_2_0,
            						"org.xtext.simple.Simple.Cardinality");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSimple.g:472:3: ( (lv_type_3_0= ruleType ) )
            // InternalSimple.g:473:4: (lv_type_3_0= ruleType )
            {
            // InternalSimple.g:473:4: (lv_type_3_0= ruleType )
            // InternalSimple.g:474:5: lv_type_3_0= ruleType
            {

            					newCompositeNode(grammarAccess.getAttributeAccess().getTypeTypeEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_4);
            lv_type_3_0=ruleType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAttributeRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_3_0,
            						"org.xtext.simple.Simple.Type");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSimple.g:491:3: ( (lv_name_4_0= ruleEString ) )
            // InternalSimple.g:492:4: (lv_name_4_0= ruleEString )
            {
            // InternalSimple.g:492:4: (lv_name_4_0= ruleEString )
            // InternalSimple.g:493:5: lv_name_4_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getAttributeAccess().getNameEStringParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_4_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAttributeRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_4_0,
            						"org.xtext.simple.Simple.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttribute"


    // $ANTLR start "entryRuleReference"
    // InternalSimple.g:514:1: entryRuleReference returns [EObject current=null] : iv_ruleReference= ruleReference EOF ;
    public final EObject entryRuleReference() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleReference = null;


        try {
            // InternalSimple.g:514:50: (iv_ruleReference= ruleReference EOF )
            // InternalSimple.g:515:2: iv_ruleReference= ruleReference EOF
            {
             newCompositeNode(grammarAccess.getReferenceRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleReference=ruleReference();

            state._fsp--;

             current =iv_ruleReference; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleReference"


    // $ANTLR start "ruleReference"
    // InternalSimple.g:521:1: ruleReference returns [EObject current=null] : ( () ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_cardinality_2_0= ruleCardinality ) ) ( (otherlv_3= RULE_ID ) ) ( (lv_name_4_0= ruleEString ) ) ) ;
    public final EObject ruleReference() throws RecognitionException {
        EObject current = null;

        Token otherlv_3=null;
        Enumerator lv_visibility_1_0 = null;

        Enumerator lv_cardinality_2_0 = null;

        AntlrDatatypeRuleToken lv_name_4_0 = null;



        	enterRule();

        try {
            // InternalSimple.g:527:2: ( ( () ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_cardinality_2_0= ruleCardinality ) ) ( (otherlv_3= RULE_ID ) ) ( (lv_name_4_0= ruleEString ) ) ) )
            // InternalSimple.g:528:2: ( () ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_cardinality_2_0= ruleCardinality ) ) ( (otherlv_3= RULE_ID ) ) ( (lv_name_4_0= ruleEString ) ) )
            {
            // InternalSimple.g:528:2: ( () ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_cardinality_2_0= ruleCardinality ) ) ( (otherlv_3= RULE_ID ) ) ( (lv_name_4_0= ruleEString ) ) )
            // InternalSimple.g:529:3: () ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_cardinality_2_0= ruleCardinality ) ) ( (otherlv_3= RULE_ID ) ) ( (lv_name_4_0= ruleEString ) )
            {
            // InternalSimple.g:529:3: ()
            // InternalSimple.g:530:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getReferenceAccess().getReferenceAction_0(),
            					current);
            			

            }

            // InternalSimple.g:536:3: ( (lv_visibility_1_0= ruleVisibility ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( ((LA10_0>=16 && LA10_0<=17)) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalSimple.g:537:4: (lv_visibility_1_0= ruleVisibility )
                    {
                    // InternalSimple.g:537:4: (lv_visibility_1_0= ruleVisibility )
                    // InternalSimple.g:538:5: lv_visibility_1_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getReferenceAccess().getVisibilityVisibilityEnumRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_10);
                    lv_visibility_1_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getReferenceRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_1_0,
                    						"org.xtext.simple.Simple.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSimple.g:555:3: ( (lv_cardinality_2_0= ruleCardinality ) )
            // InternalSimple.g:556:4: (lv_cardinality_2_0= ruleCardinality )
            {
            // InternalSimple.g:556:4: (lv_cardinality_2_0= ruleCardinality )
            // InternalSimple.g:557:5: lv_cardinality_2_0= ruleCardinality
            {

            					newCompositeNode(grammarAccess.getReferenceAccess().getCardinalityCardinalityEnumRuleCall_2_0());
            				
            pushFollow(FOLLOW_12);
            lv_cardinality_2_0=ruleCardinality();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getReferenceRule());
            					}
            					set(
            						current,
            						"cardinality",
            						lv_cardinality_2_0,
            						"org.xtext.simple.Simple.Cardinality");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSimple.g:574:3: ( (otherlv_3= RULE_ID ) )
            // InternalSimple.g:575:4: (otherlv_3= RULE_ID )
            {
            // InternalSimple.g:575:4: (otherlv_3= RULE_ID )
            // InternalSimple.g:576:5: otherlv_3= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReferenceRule());
            					}
            				
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(otherlv_3, grammarAccess.getReferenceAccess().getTypeClassCrossReference_3_0());
            				

            }


            }

            // InternalSimple.g:587:3: ( (lv_name_4_0= ruleEString ) )
            // InternalSimple.g:588:4: (lv_name_4_0= ruleEString )
            {
            // InternalSimple.g:588:4: (lv_name_4_0= ruleEString )
            // InternalSimple.g:589:5: lv_name_4_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getReferenceAccess().getNameEStringParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_4_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getReferenceRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_4_0,
            						"org.xtext.simple.Simple.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleReference"


    // $ANTLR start "ruleVisibility"
    // InternalSimple.g:610:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSimple.g:616:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) ) )
            // InternalSimple.g:617:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) )
            {
            // InternalSimple.g:617:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==16) ) {
                alt11=1;
            }
            else if ( (LA11_0==17) ) {
                alt11=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalSimple.g:618:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSimple.g:618:3: (enumLiteral_0= 'public' )
                    // InternalSimple.g:619:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,16,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPublicEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPublicEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSimple.g:626:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSimple.g:626:3: (enumLiteral_1= 'private' )
                    // InternalSimple.g:627:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,17,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPrivateEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPrivateEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleType"
    // InternalSimple.g:637:1: ruleType returns [Enumerator current=null] : ( (enumLiteral_0= 'String' ) | (enumLiteral_1= 'float' ) | (enumLiteral_2= 'integer' ) ) ;
    public final Enumerator ruleType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalSimple.g:643:2: ( ( (enumLiteral_0= 'String' ) | (enumLiteral_1= 'float' ) | (enumLiteral_2= 'integer' ) ) )
            // InternalSimple.g:644:2: ( (enumLiteral_0= 'String' ) | (enumLiteral_1= 'float' ) | (enumLiteral_2= 'integer' ) )
            {
            // InternalSimple.g:644:2: ( (enumLiteral_0= 'String' ) | (enumLiteral_1= 'float' ) | (enumLiteral_2= 'integer' ) )
            int alt12=3;
            switch ( input.LA(1) ) {
            case 18:
                {
                alt12=1;
                }
                break;
            case 19:
                {
                alt12=2;
                }
                break;
            case 20:
                {
                alt12=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }

            switch (alt12) {
                case 1 :
                    // InternalSimple.g:645:3: (enumLiteral_0= 'String' )
                    {
                    // InternalSimple.g:645:3: (enumLiteral_0= 'String' )
                    // InternalSimple.g:646:4: enumLiteral_0= 'String'
                    {
                    enumLiteral_0=(Token)match(input,18,FOLLOW_2); 

                    				current = grammarAccess.getTypeAccess().getStringEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getTypeAccess().getStringEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSimple.g:653:3: (enumLiteral_1= 'float' )
                    {
                    // InternalSimple.g:653:3: (enumLiteral_1= 'float' )
                    // InternalSimple.g:654:4: enumLiteral_1= 'float'
                    {
                    enumLiteral_1=(Token)match(input,19,FOLLOW_2); 

                    				current = grammarAccess.getTypeAccess().getFloatEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getTypeAccess().getFloatEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSimple.g:661:3: (enumLiteral_2= 'integer' )
                    {
                    // InternalSimple.g:661:3: (enumLiteral_2= 'integer' )
                    // InternalSimple.g:662:4: enumLiteral_2= 'integer'
                    {
                    enumLiteral_2=(Token)match(input,20,FOLLOW_2); 

                    				current = grammarAccess.getTypeAccess().getIntegerEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getTypeAccess().getIntegerEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleType"


    // $ANTLR start "ruleCardinality"
    // InternalSimple.g:672:1: ruleCardinality returns [Enumerator current=null] : ( (enumLiteral_0= 'mandatory' ) | (enumLiteral_1= 'optional' ) | (enumLiteral_2= 'multivalued' ) ) ;
    public final Enumerator ruleCardinality() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalSimple.g:678:2: ( ( (enumLiteral_0= 'mandatory' ) | (enumLiteral_1= 'optional' ) | (enumLiteral_2= 'multivalued' ) ) )
            // InternalSimple.g:679:2: ( (enumLiteral_0= 'mandatory' ) | (enumLiteral_1= 'optional' ) | (enumLiteral_2= 'multivalued' ) )
            {
            // InternalSimple.g:679:2: ( (enumLiteral_0= 'mandatory' ) | (enumLiteral_1= 'optional' ) | (enumLiteral_2= 'multivalued' ) )
            int alt13=3;
            switch ( input.LA(1) ) {
            case 21:
                {
                alt13=1;
                }
                break;
            case 22:
                {
                alt13=2;
                }
                break;
            case 23:
                {
                alt13=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }

            switch (alt13) {
                case 1 :
                    // InternalSimple.g:680:3: (enumLiteral_0= 'mandatory' )
                    {
                    // InternalSimple.g:680:3: (enumLiteral_0= 'mandatory' )
                    // InternalSimple.g:681:4: enumLiteral_0= 'mandatory'
                    {
                    enumLiteral_0=(Token)match(input,21,FOLLOW_2); 

                    				current = grammarAccess.getCardinalityAccess().getMandatoryEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getCardinalityAccess().getMandatoryEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSimple.g:688:3: (enumLiteral_1= 'optional' )
                    {
                    // InternalSimple.g:688:3: (enumLiteral_1= 'optional' )
                    // InternalSimple.g:689:4: enumLiteral_1= 'optional'
                    {
                    enumLiteral_1=(Token)match(input,22,FOLLOW_2); 

                    				current = grammarAccess.getCardinalityAccess().getOptionalEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getCardinalityAccess().getOptionalEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSimple.g:696:3: (enumLiteral_2= 'multivalued' )
                    {
                    // InternalSimple.g:696:3: (enumLiteral_2= 'multivalued' )
                    // InternalSimple.g:697:4: enumLiteral_2= 'multivalued'
                    {
                    enumLiteral_2=(Token)match(input,23,FOLLOW_2); 

                    				current = grammarAccess.getCardinalityAccess().getMultivaluedEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getCardinalityAccess().getMultivaluedEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCardinality"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000036800L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000E32000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000E30000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x00000000001C0000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000020L});

}