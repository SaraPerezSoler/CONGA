package org.xtext.simple;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.ecore.EObject;

public class SimpleUtils {

	public static List<simple.Class> getClasses(simple.Package p, simple.Visibility visibility) {
		List<simple.Class> classes = new ArrayList<simple.Class>();
		
		// gets all the public classes
		for (simple.Package pack : p.getPackages()) {
			classes.addAll(getClasses(pack, visibility));
		}
		for (simple.Class cl : p.getClasses()) {
			if (cl.getVisibility() == visibility) {
				if (!classes.contains(cl)) {
					classes.add(cl);
				}
			}
		}
		return classes;
	}

	public static List<String> getClassNames(simple.Package p, simple.Visibility visibility) {
		List<String> classnames = new ArrayList<String>();
		
		// gets all the public classes
		for (simple.Package pack : p.getPackages()) {
			classnames.addAll(getClassNames(pack, visibility));
		}
		for (simple.Class cl : p.getClasses()) {
			if (cl.getVisibility() == visibility) {
				if (!classnames.contains(cl.getName())) {
					classnames.add(cl.getName());
				}
			}
		}
		return classnames;
	}

	public static simple.Program getRootEObject(EObject obj) {
		// gets the root object
		simple.Program program = null;
		while ((obj != null) && (program == null)) {
			if (obj instanceof simple.Program) {
				program = (simple.Program) obj;
			}
			obj = obj.eContainer();
		}

		return program;
	}
	
	public static simple.Class findClass(simple.Package p, String name) {
		simple.Class c = null;
		for (simple.Package pack : p.getPackages()) {
			c = findClass(pack, name);
		}
		if (c == null) {
			for (simple.Class cl : p.getClasses()) {
				if (cl.getName().equals(name)) {
					c = cl;
				}
				if (c != null) {
					break;
				}
			}
		}
		return c;
	}
	
	public static boolean isParent(simple.Package p, simple.Package parent) {
		EObject obj = p;
		// loops until the root object
		simple.Program program = null;
		while ((obj != null) && (program == null)) {
			if (obj instanceof simple.Package) {
				if (obj == parent) {
					return true;
				}
			}
			if (obj instanceof simple.Program) {
				return false;
			}
			obj = obj.eContainer();
		}
		return false;
	}
}
