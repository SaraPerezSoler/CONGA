package org.xtext.simple.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.simple.services.SimpleGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSimpleParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'public'", "'private'", "'String'", "'float'", "'integer'", "'mandatory'", "'optional'", "'multivalued'", "'package'", "'{'", "'}'", "'class'", "';'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=6;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalSimpleParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSimpleParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSimpleParser.tokenNames; }
    public String getGrammarFileName() { return "InternalSimple.g"; }


    	private SimpleGrammarAccess grammarAccess;

    	public void setGrammarAccess(SimpleGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleProgram"
    // InternalSimple.g:53:1: entryRuleProgram : ruleProgram EOF ;
    public final void entryRuleProgram() throws RecognitionException {
        try {
            // InternalSimple.g:54:1: ( ruleProgram EOF )
            // InternalSimple.g:55:1: ruleProgram EOF
            {
             before(grammarAccess.getProgramRule()); 
            pushFollow(FOLLOW_1);
            ruleProgram();

            state._fsp--;

             after(grammarAccess.getProgramRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleProgram"


    // $ANTLR start "ruleProgram"
    // InternalSimple.g:62:1: ruleProgram : ( ( rule__Program__Group__0 ) ) ;
    public final void ruleProgram() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:66:2: ( ( ( rule__Program__Group__0 ) ) )
            // InternalSimple.g:67:2: ( ( rule__Program__Group__0 ) )
            {
            // InternalSimple.g:67:2: ( ( rule__Program__Group__0 ) )
            // InternalSimple.g:68:3: ( rule__Program__Group__0 )
            {
             before(grammarAccess.getProgramAccess().getGroup()); 
            // InternalSimple.g:69:3: ( rule__Program__Group__0 )
            // InternalSimple.g:69:4: rule__Program__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Program__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getProgramAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleProgram"


    // $ANTLR start "entryRulePackage"
    // InternalSimple.g:78:1: entryRulePackage : rulePackage EOF ;
    public final void entryRulePackage() throws RecognitionException {
        try {
            // InternalSimple.g:79:1: ( rulePackage EOF )
            // InternalSimple.g:80:1: rulePackage EOF
            {
             before(grammarAccess.getPackageRule()); 
            pushFollow(FOLLOW_1);
            rulePackage();

            state._fsp--;

             after(grammarAccess.getPackageRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePackage"


    // $ANTLR start "rulePackage"
    // InternalSimple.g:87:1: rulePackage : ( ( rule__Package__Group__0 ) ) ;
    public final void rulePackage() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:91:2: ( ( ( rule__Package__Group__0 ) ) )
            // InternalSimple.g:92:2: ( ( rule__Package__Group__0 ) )
            {
            // InternalSimple.g:92:2: ( ( rule__Package__Group__0 ) )
            // InternalSimple.g:93:3: ( rule__Package__Group__0 )
            {
             before(grammarAccess.getPackageAccess().getGroup()); 
            // InternalSimple.g:94:3: ( rule__Package__Group__0 )
            // InternalSimple.g:94:4: rule__Package__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Package__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPackageAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePackage"


    // $ANTLR start "entryRuleEString"
    // InternalSimple.g:103:1: entryRuleEString : ruleEString EOF ;
    public final void entryRuleEString() throws RecognitionException {
        try {
            // InternalSimple.g:104:1: ( ruleEString EOF )
            // InternalSimple.g:105:1: ruleEString EOF
            {
             before(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getEStringRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalSimple.g:112:1: ruleEString : ( ( rule__EString__Alternatives ) ) ;
    public final void ruleEString() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:116:2: ( ( ( rule__EString__Alternatives ) ) )
            // InternalSimple.g:117:2: ( ( rule__EString__Alternatives ) )
            {
            // InternalSimple.g:117:2: ( ( rule__EString__Alternatives ) )
            // InternalSimple.g:118:3: ( rule__EString__Alternatives )
            {
             before(grammarAccess.getEStringAccess().getAlternatives()); 
            // InternalSimple.g:119:3: ( rule__EString__Alternatives )
            // InternalSimple.g:119:4: rule__EString__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EString__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEStringAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleClass"
    // InternalSimple.g:128:1: entryRuleClass : ruleClass EOF ;
    public final void entryRuleClass() throws RecognitionException {
        try {
            // InternalSimple.g:129:1: ( ruleClass EOF )
            // InternalSimple.g:130:1: ruleClass EOF
            {
             before(grammarAccess.getClassRule()); 
            pushFollow(FOLLOW_1);
            ruleClass();

            state._fsp--;

             after(grammarAccess.getClassRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClass"


    // $ANTLR start "ruleClass"
    // InternalSimple.g:137:1: ruleClass : ( ( rule__Class__Group__0 ) ) ;
    public final void ruleClass() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:141:2: ( ( ( rule__Class__Group__0 ) ) )
            // InternalSimple.g:142:2: ( ( rule__Class__Group__0 ) )
            {
            // InternalSimple.g:142:2: ( ( rule__Class__Group__0 ) )
            // InternalSimple.g:143:3: ( rule__Class__Group__0 )
            {
             before(grammarAccess.getClassAccess().getGroup()); 
            // InternalSimple.g:144:3: ( rule__Class__Group__0 )
            // InternalSimple.g:144:4: rule__Class__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Class__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getClassAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClass"


    // $ANTLR start "entryRuleAttribute"
    // InternalSimple.g:153:1: entryRuleAttribute : ruleAttribute EOF ;
    public final void entryRuleAttribute() throws RecognitionException {
        try {
            // InternalSimple.g:154:1: ( ruleAttribute EOF )
            // InternalSimple.g:155:1: ruleAttribute EOF
            {
             before(grammarAccess.getAttributeRule()); 
            pushFollow(FOLLOW_1);
            ruleAttribute();

            state._fsp--;

             after(grammarAccess.getAttributeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAttribute"


    // $ANTLR start "ruleAttribute"
    // InternalSimple.g:162:1: ruleAttribute : ( ( rule__Attribute__Group__0 ) ) ;
    public final void ruleAttribute() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:166:2: ( ( ( rule__Attribute__Group__0 ) ) )
            // InternalSimple.g:167:2: ( ( rule__Attribute__Group__0 ) )
            {
            // InternalSimple.g:167:2: ( ( rule__Attribute__Group__0 ) )
            // InternalSimple.g:168:3: ( rule__Attribute__Group__0 )
            {
             before(grammarAccess.getAttributeAccess().getGroup()); 
            // InternalSimple.g:169:3: ( rule__Attribute__Group__0 )
            // InternalSimple.g:169:4: rule__Attribute__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Attribute__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getAttributeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAttribute"


    // $ANTLR start "entryRuleReference"
    // InternalSimple.g:178:1: entryRuleReference : ruleReference EOF ;
    public final void entryRuleReference() throws RecognitionException {
        try {
            // InternalSimple.g:179:1: ( ruleReference EOF )
            // InternalSimple.g:180:1: ruleReference EOF
            {
             before(grammarAccess.getReferenceRule()); 
            pushFollow(FOLLOW_1);
            ruleReference();

            state._fsp--;

             after(grammarAccess.getReferenceRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleReference"


    // $ANTLR start "ruleReference"
    // InternalSimple.g:187:1: ruleReference : ( ( rule__Reference__Group__0 ) ) ;
    public final void ruleReference() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:191:2: ( ( ( rule__Reference__Group__0 ) ) )
            // InternalSimple.g:192:2: ( ( rule__Reference__Group__0 ) )
            {
            // InternalSimple.g:192:2: ( ( rule__Reference__Group__0 ) )
            // InternalSimple.g:193:3: ( rule__Reference__Group__0 )
            {
             before(grammarAccess.getReferenceAccess().getGroup()); 
            // InternalSimple.g:194:3: ( rule__Reference__Group__0 )
            // InternalSimple.g:194:4: rule__Reference__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Reference__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getReferenceAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleReference"


    // $ANTLR start "ruleVisibility"
    // InternalSimple.g:203:1: ruleVisibility : ( ( rule__Visibility__Alternatives ) ) ;
    public final void ruleVisibility() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:207:1: ( ( ( rule__Visibility__Alternatives ) ) )
            // InternalSimple.g:208:2: ( ( rule__Visibility__Alternatives ) )
            {
            // InternalSimple.g:208:2: ( ( rule__Visibility__Alternatives ) )
            // InternalSimple.g:209:3: ( rule__Visibility__Alternatives )
            {
             before(grammarAccess.getVisibilityAccess().getAlternatives()); 
            // InternalSimple.g:210:3: ( rule__Visibility__Alternatives )
            // InternalSimple.g:210:4: rule__Visibility__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Visibility__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getVisibilityAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleType"
    // InternalSimple.g:219:1: ruleType : ( ( rule__Type__Alternatives ) ) ;
    public final void ruleType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:223:1: ( ( ( rule__Type__Alternatives ) ) )
            // InternalSimple.g:224:2: ( ( rule__Type__Alternatives ) )
            {
            // InternalSimple.g:224:2: ( ( rule__Type__Alternatives ) )
            // InternalSimple.g:225:3: ( rule__Type__Alternatives )
            {
             before(grammarAccess.getTypeAccess().getAlternatives()); 
            // InternalSimple.g:226:3: ( rule__Type__Alternatives )
            // InternalSimple.g:226:4: rule__Type__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Type__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleType"


    // $ANTLR start "ruleCardinality"
    // InternalSimple.g:235:1: ruleCardinality : ( ( rule__Cardinality__Alternatives ) ) ;
    public final void ruleCardinality() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:239:1: ( ( ( rule__Cardinality__Alternatives ) ) )
            // InternalSimple.g:240:2: ( ( rule__Cardinality__Alternatives ) )
            {
            // InternalSimple.g:240:2: ( ( rule__Cardinality__Alternatives ) )
            // InternalSimple.g:241:3: ( rule__Cardinality__Alternatives )
            {
             before(grammarAccess.getCardinalityAccess().getAlternatives()); 
            // InternalSimple.g:242:3: ( rule__Cardinality__Alternatives )
            // InternalSimple.g:242:4: rule__Cardinality__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Cardinality__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCardinalityAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCardinality"


    // $ANTLR start "rule__Package__Alternatives_4"
    // InternalSimple.g:250:1: rule__Package__Alternatives_4 : ( ( ( rule__Package__PackagesAssignment_4_0 ) ) | ( ( rule__Package__ClassesAssignment_4_1 ) ) );
    public final void rule__Package__Alternatives_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:254:1: ( ( ( rule__Package__PackagesAssignment_4_0 ) ) | ( ( rule__Package__ClassesAssignment_4_1 ) ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==19) ) {
                alt1=1;
            }
            else if ( ((LA1_0>=11 && LA1_0<=12)||LA1_0==22) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalSimple.g:255:2: ( ( rule__Package__PackagesAssignment_4_0 ) )
                    {
                    // InternalSimple.g:255:2: ( ( rule__Package__PackagesAssignment_4_0 ) )
                    // InternalSimple.g:256:3: ( rule__Package__PackagesAssignment_4_0 )
                    {
                     before(grammarAccess.getPackageAccess().getPackagesAssignment_4_0()); 
                    // InternalSimple.g:257:3: ( rule__Package__PackagesAssignment_4_0 )
                    // InternalSimple.g:257:4: rule__Package__PackagesAssignment_4_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Package__PackagesAssignment_4_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPackageAccess().getPackagesAssignment_4_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSimple.g:261:2: ( ( rule__Package__ClassesAssignment_4_1 ) )
                    {
                    // InternalSimple.g:261:2: ( ( rule__Package__ClassesAssignment_4_1 ) )
                    // InternalSimple.g:262:3: ( rule__Package__ClassesAssignment_4_1 )
                    {
                     before(grammarAccess.getPackageAccess().getClassesAssignment_4_1()); 
                    // InternalSimple.g:263:3: ( rule__Package__ClassesAssignment_4_1 )
                    // InternalSimple.g:263:4: rule__Package__ClassesAssignment_4_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Package__ClassesAssignment_4_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getPackageAccess().getClassesAssignment_4_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Alternatives_4"


    // $ANTLR start "rule__EString__Alternatives"
    // InternalSimple.g:271:1: rule__EString__Alternatives : ( ( RULE_STRING ) | ( RULE_ID ) );
    public final void rule__EString__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:275:1: ( ( RULE_STRING ) | ( RULE_ID ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==RULE_STRING) ) {
                alt2=1;
            }
            else if ( (LA2_0==RULE_ID) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalSimple.g:276:2: ( RULE_STRING )
                    {
                    // InternalSimple.g:276:2: ( RULE_STRING )
                    // InternalSimple.g:277:3: RULE_STRING
                    {
                     before(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSimple.g:282:2: ( RULE_ID )
                    {
                    // InternalSimple.g:282:2: ( RULE_ID )
                    // InternalSimple.g:283:3: RULE_ID
                    {
                     before(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EString__Alternatives"


    // $ANTLR start "rule__Class__Alternatives_5_0"
    // InternalSimple.g:292:1: rule__Class__Alternatives_5_0 : ( ( ( rule__Class__AttributesAssignment_5_0_0 ) ) | ( ( rule__Class__ReferencesAssignment_5_0_1 ) ) );
    public final void rule__Class__Alternatives_5_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:296:1: ( ( ( rule__Class__AttributesAssignment_5_0_0 ) ) | ( ( rule__Class__ReferencesAssignment_5_0_1 ) ) )
            int alt3=2;
            switch ( input.LA(1) ) {
            case 11:
                {
                switch ( input.LA(2) ) {
                case 16:
                    {
                    int LA3_3 = input.LA(3);

                    if ( (LA3_3==RULE_ID) ) {
                        alt3=2;
                    }
                    else if ( ((LA3_3>=13 && LA3_3<=15)) ) {
                        alt3=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 3, input);

                        throw nvae;
                    }
                    }
                    break;
                case 17:
                    {
                    int LA3_4 = input.LA(3);

                    if ( (LA3_4==RULE_ID) ) {
                        alt3=2;
                    }
                    else if ( ((LA3_4>=13 && LA3_4<=15)) ) {
                        alt3=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 4, input);

                        throw nvae;
                    }
                    }
                    break;
                case 18:
                    {
                    int LA3_5 = input.LA(3);

                    if ( (LA3_5==RULE_ID) ) {
                        alt3=2;
                    }
                    else if ( ((LA3_5>=13 && LA3_5<=15)) ) {
                        alt3=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 5, input);

                        throw nvae;
                    }
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 1, input);

                    throw nvae;
                }

                }
                break;
            case 12:
                {
                switch ( input.LA(2) ) {
                case 16:
                    {
                    int LA3_3 = input.LA(3);

                    if ( (LA3_3==RULE_ID) ) {
                        alt3=2;
                    }
                    else if ( ((LA3_3>=13 && LA3_3<=15)) ) {
                        alt3=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 3, input);

                        throw nvae;
                    }
                    }
                    break;
                case 17:
                    {
                    int LA3_4 = input.LA(3);

                    if ( (LA3_4==RULE_ID) ) {
                        alt3=2;
                    }
                    else if ( ((LA3_4>=13 && LA3_4<=15)) ) {
                        alt3=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 4, input);

                        throw nvae;
                    }
                    }
                    break;
                case 18:
                    {
                    int LA3_5 = input.LA(3);

                    if ( (LA3_5==RULE_ID) ) {
                        alt3=2;
                    }
                    else if ( ((LA3_5>=13 && LA3_5<=15)) ) {
                        alt3=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 5, input);

                        throw nvae;
                    }
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 2, input);

                    throw nvae;
                }

                }
                break;
            case 16:
                {
                int LA3_3 = input.LA(2);

                if ( (LA3_3==RULE_ID) ) {
                    alt3=2;
                }
                else if ( ((LA3_3>=13 && LA3_3<=15)) ) {
                    alt3=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 3, input);

                    throw nvae;
                }
                }
                break;
            case 17:
                {
                int LA3_4 = input.LA(2);

                if ( (LA3_4==RULE_ID) ) {
                    alt3=2;
                }
                else if ( ((LA3_4>=13 && LA3_4<=15)) ) {
                    alt3=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 4, input);

                    throw nvae;
                }
                }
                break;
            case 18:
                {
                int LA3_5 = input.LA(2);

                if ( (LA3_5==RULE_ID) ) {
                    alt3=2;
                }
                else if ( ((LA3_5>=13 && LA3_5<=15)) ) {
                    alt3=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 5, input);

                    throw nvae;
                }
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalSimple.g:297:2: ( ( rule__Class__AttributesAssignment_5_0_0 ) )
                    {
                    // InternalSimple.g:297:2: ( ( rule__Class__AttributesAssignment_5_0_0 ) )
                    // InternalSimple.g:298:3: ( rule__Class__AttributesAssignment_5_0_0 )
                    {
                     before(grammarAccess.getClassAccess().getAttributesAssignment_5_0_0()); 
                    // InternalSimple.g:299:3: ( rule__Class__AttributesAssignment_5_0_0 )
                    // InternalSimple.g:299:4: rule__Class__AttributesAssignment_5_0_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Class__AttributesAssignment_5_0_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getClassAccess().getAttributesAssignment_5_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSimple.g:303:2: ( ( rule__Class__ReferencesAssignment_5_0_1 ) )
                    {
                    // InternalSimple.g:303:2: ( ( rule__Class__ReferencesAssignment_5_0_1 ) )
                    // InternalSimple.g:304:3: ( rule__Class__ReferencesAssignment_5_0_1 )
                    {
                     before(grammarAccess.getClassAccess().getReferencesAssignment_5_0_1()); 
                    // InternalSimple.g:305:3: ( rule__Class__ReferencesAssignment_5_0_1 )
                    // InternalSimple.g:305:4: rule__Class__ReferencesAssignment_5_0_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Class__ReferencesAssignment_5_0_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getClassAccess().getReferencesAssignment_5_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Alternatives_5_0"


    // $ANTLR start "rule__Class__Alternatives_5_2_0"
    // InternalSimple.g:313:1: rule__Class__Alternatives_5_2_0 : ( ( ( rule__Class__AttributesAssignment_5_2_0_0 ) ) | ( ( rule__Class__ReferencesAssignment_5_2_0_1 ) ) );
    public final void rule__Class__Alternatives_5_2_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:317:1: ( ( ( rule__Class__AttributesAssignment_5_2_0_0 ) ) | ( ( rule__Class__ReferencesAssignment_5_2_0_1 ) ) )
            int alt4=2;
            switch ( input.LA(1) ) {
            case 11:
                {
                switch ( input.LA(2) ) {
                case 16:
                    {
                    int LA4_3 = input.LA(3);

                    if ( (LA4_3==RULE_ID) ) {
                        alt4=2;
                    }
                    else if ( ((LA4_3>=13 && LA4_3<=15)) ) {
                        alt4=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 3, input);

                        throw nvae;
                    }
                    }
                    break;
                case 17:
                    {
                    int LA4_4 = input.LA(3);

                    if ( (LA4_4==RULE_ID) ) {
                        alt4=2;
                    }
                    else if ( ((LA4_4>=13 && LA4_4<=15)) ) {
                        alt4=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 4, input);

                        throw nvae;
                    }
                    }
                    break;
                case 18:
                    {
                    int LA4_5 = input.LA(3);

                    if ( (LA4_5==RULE_ID) ) {
                        alt4=2;
                    }
                    else if ( ((LA4_5>=13 && LA4_5<=15)) ) {
                        alt4=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 5, input);

                        throw nvae;
                    }
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 1, input);

                    throw nvae;
                }

                }
                break;
            case 12:
                {
                switch ( input.LA(2) ) {
                case 16:
                    {
                    int LA4_3 = input.LA(3);

                    if ( (LA4_3==RULE_ID) ) {
                        alt4=2;
                    }
                    else if ( ((LA4_3>=13 && LA4_3<=15)) ) {
                        alt4=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 3, input);

                        throw nvae;
                    }
                    }
                    break;
                case 17:
                    {
                    int LA4_4 = input.LA(3);

                    if ( (LA4_4==RULE_ID) ) {
                        alt4=2;
                    }
                    else if ( ((LA4_4>=13 && LA4_4<=15)) ) {
                        alt4=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 4, input);

                        throw nvae;
                    }
                    }
                    break;
                case 18:
                    {
                    int LA4_5 = input.LA(3);

                    if ( (LA4_5==RULE_ID) ) {
                        alt4=2;
                    }
                    else if ( ((LA4_5>=13 && LA4_5<=15)) ) {
                        alt4=1;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 5, input);

                        throw nvae;
                    }
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 2, input);

                    throw nvae;
                }

                }
                break;
            case 16:
                {
                int LA4_3 = input.LA(2);

                if ( (LA4_3==RULE_ID) ) {
                    alt4=2;
                }
                else if ( ((LA4_3>=13 && LA4_3<=15)) ) {
                    alt4=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 3, input);

                    throw nvae;
                }
                }
                break;
            case 17:
                {
                int LA4_4 = input.LA(2);

                if ( (LA4_4==RULE_ID) ) {
                    alt4=2;
                }
                else if ( ((LA4_4>=13 && LA4_4<=15)) ) {
                    alt4=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 4, input);

                    throw nvae;
                }
                }
                break;
            case 18:
                {
                int LA4_5 = input.LA(2);

                if ( (LA4_5==RULE_ID) ) {
                    alt4=2;
                }
                else if ( ((LA4_5>=13 && LA4_5<=15)) ) {
                    alt4=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 5, input);

                    throw nvae;
                }
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // InternalSimple.g:318:2: ( ( rule__Class__AttributesAssignment_5_2_0_0 ) )
                    {
                    // InternalSimple.g:318:2: ( ( rule__Class__AttributesAssignment_5_2_0_0 ) )
                    // InternalSimple.g:319:3: ( rule__Class__AttributesAssignment_5_2_0_0 )
                    {
                     before(grammarAccess.getClassAccess().getAttributesAssignment_5_2_0_0()); 
                    // InternalSimple.g:320:3: ( rule__Class__AttributesAssignment_5_2_0_0 )
                    // InternalSimple.g:320:4: rule__Class__AttributesAssignment_5_2_0_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Class__AttributesAssignment_5_2_0_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getClassAccess().getAttributesAssignment_5_2_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSimple.g:324:2: ( ( rule__Class__ReferencesAssignment_5_2_0_1 ) )
                    {
                    // InternalSimple.g:324:2: ( ( rule__Class__ReferencesAssignment_5_2_0_1 ) )
                    // InternalSimple.g:325:3: ( rule__Class__ReferencesAssignment_5_2_0_1 )
                    {
                     before(grammarAccess.getClassAccess().getReferencesAssignment_5_2_0_1()); 
                    // InternalSimple.g:326:3: ( rule__Class__ReferencesAssignment_5_2_0_1 )
                    // InternalSimple.g:326:4: rule__Class__ReferencesAssignment_5_2_0_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Class__ReferencesAssignment_5_2_0_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getClassAccess().getReferencesAssignment_5_2_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Alternatives_5_2_0"


    // $ANTLR start "rule__Visibility__Alternatives"
    // InternalSimple.g:334:1: rule__Visibility__Alternatives : ( ( ( 'public' ) ) | ( ( 'private' ) ) );
    public final void rule__Visibility__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:338:1: ( ( ( 'public' ) ) | ( ( 'private' ) ) )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==11) ) {
                alt5=1;
            }
            else if ( (LA5_0==12) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalSimple.g:339:2: ( ( 'public' ) )
                    {
                    // InternalSimple.g:339:2: ( ( 'public' ) )
                    // InternalSimple.g:340:3: ( 'public' )
                    {
                     before(grammarAccess.getVisibilityAccess().getPublicEnumLiteralDeclaration_0()); 
                    // InternalSimple.g:341:3: ( 'public' )
                    // InternalSimple.g:341:4: 'public'
                    {
                    match(input,11,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getPublicEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSimple.g:345:2: ( ( 'private' ) )
                    {
                    // InternalSimple.g:345:2: ( ( 'private' ) )
                    // InternalSimple.g:346:3: ( 'private' )
                    {
                     before(grammarAccess.getVisibilityAccess().getPrivateEnumLiteralDeclaration_1()); 
                    // InternalSimple.g:347:3: ( 'private' )
                    // InternalSimple.g:347:4: 'private'
                    {
                    match(input,12,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getPrivateEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Visibility__Alternatives"


    // $ANTLR start "rule__Type__Alternatives"
    // InternalSimple.g:355:1: rule__Type__Alternatives : ( ( ( 'String' ) ) | ( ( 'float' ) ) | ( ( 'integer' ) ) );
    public final void rule__Type__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:359:1: ( ( ( 'String' ) ) | ( ( 'float' ) ) | ( ( 'integer' ) ) )
            int alt6=3;
            switch ( input.LA(1) ) {
            case 13:
                {
                alt6=1;
                }
                break;
            case 14:
                {
                alt6=2;
                }
                break;
            case 15:
                {
                alt6=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // InternalSimple.g:360:2: ( ( 'String' ) )
                    {
                    // InternalSimple.g:360:2: ( ( 'String' ) )
                    // InternalSimple.g:361:3: ( 'String' )
                    {
                     before(grammarAccess.getTypeAccess().getStringEnumLiteralDeclaration_0()); 
                    // InternalSimple.g:362:3: ( 'String' )
                    // InternalSimple.g:362:4: 'String'
                    {
                    match(input,13,FOLLOW_2); 

                    }

                     after(grammarAccess.getTypeAccess().getStringEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSimple.g:366:2: ( ( 'float' ) )
                    {
                    // InternalSimple.g:366:2: ( ( 'float' ) )
                    // InternalSimple.g:367:3: ( 'float' )
                    {
                     before(grammarAccess.getTypeAccess().getFloatEnumLiteralDeclaration_1()); 
                    // InternalSimple.g:368:3: ( 'float' )
                    // InternalSimple.g:368:4: 'float'
                    {
                    match(input,14,FOLLOW_2); 

                    }

                     after(grammarAccess.getTypeAccess().getFloatEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSimple.g:372:2: ( ( 'integer' ) )
                    {
                    // InternalSimple.g:372:2: ( ( 'integer' ) )
                    // InternalSimple.g:373:3: ( 'integer' )
                    {
                     before(grammarAccess.getTypeAccess().getIntegerEnumLiteralDeclaration_2()); 
                    // InternalSimple.g:374:3: ( 'integer' )
                    // InternalSimple.g:374:4: 'integer'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getTypeAccess().getIntegerEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__Alternatives"


    // $ANTLR start "rule__Cardinality__Alternatives"
    // InternalSimple.g:382:1: rule__Cardinality__Alternatives : ( ( ( 'mandatory' ) ) | ( ( 'optional' ) ) | ( ( 'multivalued' ) ) );
    public final void rule__Cardinality__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:386:1: ( ( ( 'mandatory' ) ) | ( ( 'optional' ) ) | ( ( 'multivalued' ) ) )
            int alt7=3;
            switch ( input.LA(1) ) {
            case 16:
                {
                alt7=1;
                }
                break;
            case 17:
                {
                alt7=2;
                }
                break;
            case 18:
                {
                alt7=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // InternalSimple.g:387:2: ( ( 'mandatory' ) )
                    {
                    // InternalSimple.g:387:2: ( ( 'mandatory' ) )
                    // InternalSimple.g:388:3: ( 'mandatory' )
                    {
                     before(grammarAccess.getCardinalityAccess().getMandatoryEnumLiteralDeclaration_0()); 
                    // InternalSimple.g:389:3: ( 'mandatory' )
                    // InternalSimple.g:389:4: 'mandatory'
                    {
                    match(input,16,FOLLOW_2); 

                    }

                     after(grammarAccess.getCardinalityAccess().getMandatoryEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSimple.g:393:2: ( ( 'optional' ) )
                    {
                    // InternalSimple.g:393:2: ( ( 'optional' ) )
                    // InternalSimple.g:394:3: ( 'optional' )
                    {
                     before(grammarAccess.getCardinalityAccess().getOptionalEnumLiteralDeclaration_1()); 
                    // InternalSimple.g:395:3: ( 'optional' )
                    // InternalSimple.g:395:4: 'optional'
                    {
                    match(input,17,FOLLOW_2); 

                    }

                     after(grammarAccess.getCardinalityAccess().getOptionalEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSimple.g:399:2: ( ( 'multivalued' ) )
                    {
                    // InternalSimple.g:399:2: ( ( 'multivalued' ) )
                    // InternalSimple.g:400:3: ( 'multivalued' )
                    {
                     before(grammarAccess.getCardinalityAccess().getMultivaluedEnumLiteralDeclaration_2()); 
                    // InternalSimple.g:401:3: ( 'multivalued' )
                    // InternalSimple.g:401:4: 'multivalued'
                    {
                    match(input,18,FOLLOW_2); 

                    }

                     after(grammarAccess.getCardinalityAccess().getMultivaluedEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Cardinality__Alternatives"


    // $ANTLR start "rule__Program__Group__0"
    // InternalSimple.g:409:1: rule__Program__Group__0 : rule__Program__Group__0__Impl rule__Program__Group__1 ;
    public final void rule__Program__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:413:1: ( rule__Program__Group__0__Impl rule__Program__Group__1 )
            // InternalSimple.g:414:2: rule__Program__Group__0__Impl rule__Program__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Program__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Program__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__Group__0"


    // $ANTLR start "rule__Program__Group__0__Impl"
    // InternalSimple.g:421:1: rule__Program__Group__0__Impl : ( () ) ;
    public final void rule__Program__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:425:1: ( ( () ) )
            // InternalSimple.g:426:1: ( () )
            {
            // InternalSimple.g:426:1: ( () )
            // InternalSimple.g:427:2: ()
            {
             before(grammarAccess.getProgramAccess().getProgramAction_0()); 
            // InternalSimple.g:428:2: ()
            // InternalSimple.g:428:3: 
            {
            }

             after(grammarAccess.getProgramAccess().getProgramAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__Group__0__Impl"


    // $ANTLR start "rule__Program__Group__1"
    // InternalSimple.g:436:1: rule__Program__Group__1 : rule__Program__Group__1__Impl ;
    public final void rule__Program__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:440:1: ( rule__Program__Group__1__Impl )
            // InternalSimple.g:441:2: rule__Program__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Program__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__Group__1"


    // $ANTLR start "rule__Program__Group__1__Impl"
    // InternalSimple.g:447:1: rule__Program__Group__1__Impl : ( ( ( rule__Program__PackagesAssignment_1 ) ) ( ( rule__Program__PackagesAssignment_1 )* ) ) ;
    public final void rule__Program__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:451:1: ( ( ( ( rule__Program__PackagesAssignment_1 ) ) ( ( rule__Program__PackagesAssignment_1 )* ) ) )
            // InternalSimple.g:452:1: ( ( ( rule__Program__PackagesAssignment_1 ) ) ( ( rule__Program__PackagesAssignment_1 )* ) )
            {
            // InternalSimple.g:452:1: ( ( ( rule__Program__PackagesAssignment_1 ) ) ( ( rule__Program__PackagesAssignment_1 )* ) )
            // InternalSimple.g:453:2: ( ( rule__Program__PackagesAssignment_1 ) ) ( ( rule__Program__PackagesAssignment_1 )* )
            {
            // InternalSimple.g:453:2: ( ( rule__Program__PackagesAssignment_1 ) )
            // InternalSimple.g:454:3: ( rule__Program__PackagesAssignment_1 )
            {
             before(grammarAccess.getProgramAccess().getPackagesAssignment_1()); 
            // InternalSimple.g:455:3: ( rule__Program__PackagesAssignment_1 )
            // InternalSimple.g:455:4: rule__Program__PackagesAssignment_1
            {
            pushFollow(FOLLOW_4);
            rule__Program__PackagesAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getProgramAccess().getPackagesAssignment_1()); 

            }

            // InternalSimple.g:458:2: ( ( rule__Program__PackagesAssignment_1 )* )
            // InternalSimple.g:459:3: ( rule__Program__PackagesAssignment_1 )*
            {
             before(grammarAccess.getProgramAccess().getPackagesAssignment_1()); 
            // InternalSimple.g:460:3: ( rule__Program__PackagesAssignment_1 )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==19) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalSimple.g:460:4: rule__Program__PackagesAssignment_1
            	    {
            	    pushFollow(FOLLOW_4);
            	    rule__Program__PackagesAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

             after(grammarAccess.getProgramAccess().getPackagesAssignment_1()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__Group__1__Impl"


    // $ANTLR start "rule__Package__Group__0"
    // InternalSimple.g:470:1: rule__Package__Group__0 : rule__Package__Group__0__Impl rule__Package__Group__1 ;
    public final void rule__Package__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:474:1: ( rule__Package__Group__0__Impl rule__Package__Group__1 )
            // InternalSimple.g:475:2: rule__Package__Group__0__Impl rule__Package__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Package__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Package__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__0"


    // $ANTLR start "rule__Package__Group__0__Impl"
    // InternalSimple.g:482:1: rule__Package__Group__0__Impl : ( () ) ;
    public final void rule__Package__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:486:1: ( ( () ) )
            // InternalSimple.g:487:1: ( () )
            {
            // InternalSimple.g:487:1: ( () )
            // InternalSimple.g:488:2: ()
            {
             before(grammarAccess.getPackageAccess().getPackageAction_0()); 
            // InternalSimple.g:489:2: ()
            // InternalSimple.g:489:3: 
            {
            }

             after(grammarAccess.getPackageAccess().getPackageAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__0__Impl"


    // $ANTLR start "rule__Package__Group__1"
    // InternalSimple.g:497:1: rule__Package__Group__1 : rule__Package__Group__1__Impl rule__Package__Group__2 ;
    public final void rule__Package__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:501:1: ( rule__Package__Group__1__Impl rule__Package__Group__2 )
            // InternalSimple.g:502:2: rule__Package__Group__1__Impl rule__Package__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Package__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Package__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__1"


    // $ANTLR start "rule__Package__Group__1__Impl"
    // InternalSimple.g:509:1: rule__Package__Group__1__Impl : ( 'package' ) ;
    public final void rule__Package__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:513:1: ( ( 'package' ) )
            // InternalSimple.g:514:1: ( 'package' )
            {
            // InternalSimple.g:514:1: ( 'package' )
            // InternalSimple.g:515:2: 'package'
            {
             before(grammarAccess.getPackageAccess().getPackageKeyword_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getPackageAccess().getPackageKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__1__Impl"


    // $ANTLR start "rule__Package__Group__2"
    // InternalSimple.g:524:1: rule__Package__Group__2 : rule__Package__Group__2__Impl rule__Package__Group__3 ;
    public final void rule__Package__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:528:1: ( rule__Package__Group__2__Impl rule__Package__Group__3 )
            // InternalSimple.g:529:2: rule__Package__Group__2__Impl rule__Package__Group__3
            {
            pushFollow(FOLLOW_6);
            rule__Package__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Package__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__2"


    // $ANTLR start "rule__Package__Group__2__Impl"
    // InternalSimple.g:536:1: rule__Package__Group__2__Impl : ( ( rule__Package__NameAssignment_2 ) ) ;
    public final void rule__Package__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:540:1: ( ( ( rule__Package__NameAssignment_2 ) ) )
            // InternalSimple.g:541:1: ( ( rule__Package__NameAssignment_2 ) )
            {
            // InternalSimple.g:541:1: ( ( rule__Package__NameAssignment_2 ) )
            // InternalSimple.g:542:2: ( rule__Package__NameAssignment_2 )
            {
             before(grammarAccess.getPackageAccess().getNameAssignment_2()); 
            // InternalSimple.g:543:2: ( rule__Package__NameAssignment_2 )
            // InternalSimple.g:543:3: rule__Package__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Package__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getPackageAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__2__Impl"


    // $ANTLR start "rule__Package__Group__3"
    // InternalSimple.g:551:1: rule__Package__Group__3 : rule__Package__Group__3__Impl rule__Package__Group__4 ;
    public final void rule__Package__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:555:1: ( rule__Package__Group__3__Impl rule__Package__Group__4 )
            // InternalSimple.g:556:2: rule__Package__Group__3__Impl rule__Package__Group__4
            {
            pushFollow(FOLLOW_7);
            rule__Package__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Package__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__3"


    // $ANTLR start "rule__Package__Group__3__Impl"
    // InternalSimple.g:563:1: rule__Package__Group__3__Impl : ( '{' ) ;
    public final void rule__Package__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:567:1: ( ( '{' ) )
            // InternalSimple.g:568:1: ( '{' )
            {
            // InternalSimple.g:568:1: ( '{' )
            // InternalSimple.g:569:2: '{'
            {
             before(grammarAccess.getPackageAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getPackageAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__3__Impl"


    // $ANTLR start "rule__Package__Group__4"
    // InternalSimple.g:578:1: rule__Package__Group__4 : rule__Package__Group__4__Impl rule__Package__Group__5 ;
    public final void rule__Package__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:582:1: ( rule__Package__Group__4__Impl rule__Package__Group__5 )
            // InternalSimple.g:583:2: rule__Package__Group__4__Impl rule__Package__Group__5
            {
            pushFollow(FOLLOW_7);
            rule__Package__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Package__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__4"


    // $ANTLR start "rule__Package__Group__4__Impl"
    // InternalSimple.g:590:1: rule__Package__Group__4__Impl : ( ( rule__Package__Alternatives_4 )* ) ;
    public final void rule__Package__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:594:1: ( ( ( rule__Package__Alternatives_4 )* ) )
            // InternalSimple.g:595:1: ( ( rule__Package__Alternatives_4 )* )
            {
            // InternalSimple.g:595:1: ( ( rule__Package__Alternatives_4 )* )
            // InternalSimple.g:596:2: ( rule__Package__Alternatives_4 )*
            {
             before(grammarAccess.getPackageAccess().getAlternatives_4()); 
            // InternalSimple.g:597:2: ( rule__Package__Alternatives_4 )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( ((LA9_0>=11 && LA9_0<=12)||LA9_0==19||LA9_0==22) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalSimple.g:597:3: rule__Package__Alternatives_4
            	    {
            	    pushFollow(FOLLOW_8);
            	    rule__Package__Alternatives_4();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

             after(grammarAccess.getPackageAccess().getAlternatives_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__4__Impl"


    // $ANTLR start "rule__Package__Group__5"
    // InternalSimple.g:605:1: rule__Package__Group__5 : rule__Package__Group__5__Impl ;
    public final void rule__Package__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:609:1: ( rule__Package__Group__5__Impl )
            // InternalSimple.g:610:2: rule__Package__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Package__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__5"


    // $ANTLR start "rule__Package__Group__5__Impl"
    // InternalSimple.g:616:1: rule__Package__Group__5__Impl : ( '}' ) ;
    public final void rule__Package__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:620:1: ( ( '}' ) )
            // InternalSimple.g:621:1: ( '}' )
            {
            // InternalSimple.g:621:1: ( '}' )
            // InternalSimple.g:622:2: '}'
            {
             before(grammarAccess.getPackageAccess().getRightCurlyBracketKeyword_5()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getPackageAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__Group__5__Impl"


    // $ANTLR start "rule__Class__Group__0"
    // InternalSimple.g:632:1: rule__Class__Group__0 : rule__Class__Group__0__Impl rule__Class__Group__1 ;
    public final void rule__Class__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:636:1: ( rule__Class__Group__0__Impl rule__Class__Group__1 )
            // InternalSimple.g:637:2: rule__Class__Group__0__Impl rule__Class__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__Class__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Class__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__0"


    // $ANTLR start "rule__Class__Group__0__Impl"
    // InternalSimple.g:644:1: rule__Class__Group__0__Impl : ( () ) ;
    public final void rule__Class__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:648:1: ( ( () ) )
            // InternalSimple.g:649:1: ( () )
            {
            // InternalSimple.g:649:1: ( () )
            // InternalSimple.g:650:2: ()
            {
             before(grammarAccess.getClassAccess().getClassAction_0()); 
            // InternalSimple.g:651:2: ()
            // InternalSimple.g:651:3: 
            {
            }

             after(grammarAccess.getClassAccess().getClassAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__0__Impl"


    // $ANTLR start "rule__Class__Group__1"
    // InternalSimple.g:659:1: rule__Class__Group__1 : rule__Class__Group__1__Impl rule__Class__Group__2 ;
    public final void rule__Class__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:663:1: ( rule__Class__Group__1__Impl rule__Class__Group__2 )
            // InternalSimple.g:664:2: rule__Class__Group__1__Impl rule__Class__Group__2
            {
            pushFollow(FOLLOW_9);
            rule__Class__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Class__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__1"


    // $ANTLR start "rule__Class__Group__1__Impl"
    // InternalSimple.g:671:1: rule__Class__Group__1__Impl : ( ( rule__Class__VisibilityAssignment_1 )? ) ;
    public final void rule__Class__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:675:1: ( ( ( rule__Class__VisibilityAssignment_1 )? ) )
            // InternalSimple.g:676:1: ( ( rule__Class__VisibilityAssignment_1 )? )
            {
            // InternalSimple.g:676:1: ( ( rule__Class__VisibilityAssignment_1 )? )
            // InternalSimple.g:677:2: ( rule__Class__VisibilityAssignment_1 )?
            {
             before(grammarAccess.getClassAccess().getVisibilityAssignment_1()); 
            // InternalSimple.g:678:2: ( rule__Class__VisibilityAssignment_1 )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( ((LA10_0>=11 && LA10_0<=12)) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalSimple.g:678:3: rule__Class__VisibilityAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Class__VisibilityAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClassAccess().getVisibilityAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__1__Impl"


    // $ANTLR start "rule__Class__Group__2"
    // InternalSimple.g:686:1: rule__Class__Group__2 : rule__Class__Group__2__Impl rule__Class__Group__3 ;
    public final void rule__Class__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:690:1: ( rule__Class__Group__2__Impl rule__Class__Group__3 )
            // InternalSimple.g:691:2: rule__Class__Group__2__Impl rule__Class__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Class__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Class__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__2"


    // $ANTLR start "rule__Class__Group__2__Impl"
    // InternalSimple.g:698:1: rule__Class__Group__2__Impl : ( 'class' ) ;
    public final void rule__Class__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:702:1: ( ( 'class' ) )
            // InternalSimple.g:703:1: ( 'class' )
            {
            // InternalSimple.g:703:1: ( 'class' )
            // InternalSimple.g:704:2: 'class'
            {
             before(grammarAccess.getClassAccess().getClassKeyword_2()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getClassAccess().getClassKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__2__Impl"


    // $ANTLR start "rule__Class__Group__3"
    // InternalSimple.g:713:1: rule__Class__Group__3 : rule__Class__Group__3__Impl rule__Class__Group__4 ;
    public final void rule__Class__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:717:1: ( rule__Class__Group__3__Impl rule__Class__Group__4 )
            // InternalSimple.g:718:2: rule__Class__Group__3__Impl rule__Class__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__Class__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Class__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__3"


    // $ANTLR start "rule__Class__Group__3__Impl"
    // InternalSimple.g:725:1: rule__Class__Group__3__Impl : ( ( rule__Class__NameAssignment_3 ) ) ;
    public final void rule__Class__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:729:1: ( ( ( rule__Class__NameAssignment_3 ) ) )
            // InternalSimple.g:730:1: ( ( rule__Class__NameAssignment_3 ) )
            {
            // InternalSimple.g:730:1: ( ( rule__Class__NameAssignment_3 ) )
            // InternalSimple.g:731:2: ( rule__Class__NameAssignment_3 )
            {
             before(grammarAccess.getClassAccess().getNameAssignment_3()); 
            // InternalSimple.g:732:2: ( rule__Class__NameAssignment_3 )
            // InternalSimple.g:732:3: rule__Class__NameAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Class__NameAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getClassAccess().getNameAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__3__Impl"


    // $ANTLR start "rule__Class__Group__4"
    // InternalSimple.g:740:1: rule__Class__Group__4 : rule__Class__Group__4__Impl rule__Class__Group__5 ;
    public final void rule__Class__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:744:1: ( rule__Class__Group__4__Impl rule__Class__Group__5 )
            // InternalSimple.g:745:2: rule__Class__Group__4__Impl rule__Class__Group__5
            {
            pushFollow(FOLLOW_10);
            rule__Class__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Class__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__4"


    // $ANTLR start "rule__Class__Group__4__Impl"
    // InternalSimple.g:752:1: rule__Class__Group__4__Impl : ( '{' ) ;
    public final void rule__Class__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:756:1: ( ( '{' ) )
            // InternalSimple.g:757:1: ( '{' )
            {
            // InternalSimple.g:757:1: ( '{' )
            // InternalSimple.g:758:2: '{'
            {
             before(grammarAccess.getClassAccess().getLeftCurlyBracketKeyword_4()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getClassAccess().getLeftCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__4__Impl"


    // $ANTLR start "rule__Class__Group__5"
    // InternalSimple.g:767:1: rule__Class__Group__5 : rule__Class__Group__5__Impl rule__Class__Group__6 ;
    public final void rule__Class__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:771:1: ( rule__Class__Group__5__Impl rule__Class__Group__6 )
            // InternalSimple.g:772:2: rule__Class__Group__5__Impl rule__Class__Group__6
            {
            pushFollow(FOLLOW_10);
            rule__Class__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Class__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__5"


    // $ANTLR start "rule__Class__Group__5__Impl"
    // InternalSimple.g:779:1: rule__Class__Group__5__Impl : ( ( rule__Class__Group_5__0 )? ) ;
    public final void rule__Class__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:783:1: ( ( ( rule__Class__Group_5__0 )? ) )
            // InternalSimple.g:784:1: ( ( rule__Class__Group_5__0 )? )
            {
            // InternalSimple.g:784:1: ( ( rule__Class__Group_5__0 )? )
            // InternalSimple.g:785:2: ( rule__Class__Group_5__0 )?
            {
             before(grammarAccess.getClassAccess().getGroup_5()); 
            // InternalSimple.g:786:2: ( rule__Class__Group_5__0 )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( ((LA11_0>=11 && LA11_0<=12)||(LA11_0>=16 && LA11_0<=18)) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalSimple.g:786:3: rule__Class__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Class__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClassAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__5__Impl"


    // $ANTLR start "rule__Class__Group__6"
    // InternalSimple.g:794:1: rule__Class__Group__6 : rule__Class__Group__6__Impl ;
    public final void rule__Class__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:798:1: ( rule__Class__Group__6__Impl )
            // InternalSimple.g:799:2: rule__Class__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Class__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__6"


    // $ANTLR start "rule__Class__Group__6__Impl"
    // InternalSimple.g:805:1: rule__Class__Group__6__Impl : ( '}' ) ;
    public final void rule__Class__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:809:1: ( ( '}' ) )
            // InternalSimple.g:810:1: ( '}' )
            {
            // InternalSimple.g:810:1: ( '}' )
            // InternalSimple.g:811:2: '}'
            {
             before(grammarAccess.getClassAccess().getRightCurlyBracketKeyword_6()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getClassAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group__6__Impl"


    // $ANTLR start "rule__Class__Group_5__0"
    // InternalSimple.g:821:1: rule__Class__Group_5__0 : rule__Class__Group_5__0__Impl rule__Class__Group_5__1 ;
    public final void rule__Class__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:825:1: ( rule__Class__Group_5__0__Impl rule__Class__Group_5__1 )
            // InternalSimple.g:826:2: rule__Class__Group_5__0__Impl rule__Class__Group_5__1
            {
            pushFollow(FOLLOW_11);
            rule__Class__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Class__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group_5__0"


    // $ANTLR start "rule__Class__Group_5__0__Impl"
    // InternalSimple.g:833:1: rule__Class__Group_5__0__Impl : ( ( rule__Class__Alternatives_5_0 ) ) ;
    public final void rule__Class__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:837:1: ( ( ( rule__Class__Alternatives_5_0 ) ) )
            // InternalSimple.g:838:1: ( ( rule__Class__Alternatives_5_0 ) )
            {
            // InternalSimple.g:838:1: ( ( rule__Class__Alternatives_5_0 ) )
            // InternalSimple.g:839:2: ( rule__Class__Alternatives_5_0 )
            {
             before(grammarAccess.getClassAccess().getAlternatives_5_0()); 
            // InternalSimple.g:840:2: ( rule__Class__Alternatives_5_0 )
            // InternalSimple.g:840:3: rule__Class__Alternatives_5_0
            {
            pushFollow(FOLLOW_2);
            rule__Class__Alternatives_5_0();

            state._fsp--;


            }

             after(grammarAccess.getClassAccess().getAlternatives_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group_5__0__Impl"


    // $ANTLR start "rule__Class__Group_5__1"
    // InternalSimple.g:848:1: rule__Class__Group_5__1 : rule__Class__Group_5__1__Impl rule__Class__Group_5__2 ;
    public final void rule__Class__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:852:1: ( rule__Class__Group_5__1__Impl rule__Class__Group_5__2 )
            // InternalSimple.g:853:2: rule__Class__Group_5__1__Impl rule__Class__Group_5__2
            {
            pushFollow(FOLLOW_12);
            rule__Class__Group_5__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Class__Group_5__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group_5__1"


    // $ANTLR start "rule__Class__Group_5__1__Impl"
    // InternalSimple.g:860:1: rule__Class__Group_5__1__Impl : ( ';' ) ;
    public final void rule__Class__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:864:1: ( ( ';' ) )
            // InternalSimple.g:865:1: ( ';' )
            {
            // InternalSimple.g:865:1: ( ';' )
            // InternalSimple.g:866:2: ';'
            {
             before(grammarAccess.getClassAccess().getSemicolonKeyword_5_1()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getClassAccess().getSemicolonKeyword_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group_5__1__Impl"


    // $ANTLR start "rule__Class__Group_5__2"
    // InternalSimple.g:875:1: rule__Class__Group_5__2 : rule__Class__Group_5__2__Impl ;
    public final void rule__Class__Group_5__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:879:1: ( rule__Class__Group_5__2__Impl )
            // InternalSimple.g:880:2: rule__Class__Group_5__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Class__Group_5__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group_5__2"


    // $ANTLR start "rule__Class__Group_5__2__Impl"
    // InternalSimple.g:886:1: rule__Class__Group_5__2__Impl : ( ( rule__Class__Group_5_2__0 )* ) ;
    public final void rule__Class__Group_5__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:890:1: ( ( ( rule__Class__Group_5_2__0 )* ) )
            // InternalSimple.g:891:1: ( ( rule__Class__Group_5_2__0 )* )
            {
            // InternalSimple.g:891:1: ( ( rule__Class__Group_5_2__0 )* )
            // InternalSimple.g:892:2: ( rule__Class__Group_5_2__0 )*
            {
             before(grammarAccess.getClassAccess().getGroup_5_2()); 
            // InternalSimple.g:893:2: ( rule__Class__Group_5_2__0 )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( ((LA12_0>=11 && LA12_0<=12)||(LA12_0>=16 && LA12_0<=18)) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalSimple.g:893:3: rule__Class__Group_5_2__0
            	    {
            	    pushFollow(FOLLOW_13);
            	    rule__Class__Group_5_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

             after(grammarAccess.getClassAccess().getGroup_5_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group_5__2__Impl"


    // $ANTLR start "rule__Class__Group_5_2__0"
    // InternalSimple.g:902:1: rule__Class__Group_5_2__0 : rule__Class__Group_5_2__0__Impl rule__Class__Group_5_2__1 ;
    public final void rule__Class__Group_5_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:906:1: ( rule__Class__Group_5_2__0__Impl rule__Class__Group_5_2__1 )
            // InternalSimple.g:907:2: rule__Class__Group_5_2__0__Impl rule__Class__Group_5_2__1
            {
            pushFollow(FOLLOW_11);
            rule__Class__Group_5_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Class__Group_5_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group_5_2__0"


    // $ANTLR start "rule__Class__Group_5_2__0__Impl"
    // InternalSimple.g:914:1: rule__Class__Group_5_2__0__Impl : ( ( rule__Class__Alternatives_5_2_0 ) ) ;
    public final void rule__Class__Group_5_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:918:1: ( ( ( rule__Class__Alternatives_5_2_0 ) ) )
            // InternalSimple.g:919:1: ( ( rule__Class__Alternatives_5_2_0 ) )
            {
            // InternalSimple.g:919:1: ( ( rule__Class__Alternatives_5_2_0 ) )
            // InternalSimple.g:920:2: ( rule__Class__Alternatives_5_2_0 )
            {
             before(grammarAccess.getClassAccess().getAlternatives_5_2_0()); 
            // InternalSimple.g:921:2: ( rule__Class__Alternatives_5_2_0 )
            // InternalSimple.g:921:3: rule__Class__Alternatives_5_2_0
            {
            pushFollow(FOLLOW_2);
            rule__Class__Alternatives_5_2_0();

            state._fsp--;


            }

             after(grammarAccess.getClassAccess().getAlternatives_5_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group_5_2__0__Impl"


    // $ANTLR start "rule__Class__Group_5_2__1"
    // InternalSimple.g:929:1: rule__Class__Group_5_2__1 : rule__Class__Group_5_2__1__Impl ;
    public final void rule__Class__Group_5_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:933:1: ( rule__Class__Group_5_2__1__Impl )
            // InternalSimple.g:934:2: rule__Class__Group_5_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Class__Group_5_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group_5_2__1"


    // $ANTLR start "rule__Class__Group_5_2__1__Impl"
    // InternalSimple.g:940:1: rule__Class__Group_5_2__1__Impl : ( ';' ) ;
    public final void rule__Class__Group_5_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:944:1: ( ( ';' ) )
            // InternalSimple.g:945:1: ( ';' )
            {
            // InternalSimple.g:945:1: ( ';' )
            // InternalSimple.g:946:2: ';'
            {
             before(grammarAccess.getClassAccess().getSemicolonKeyword_5_2_1()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getClassAccess().getSemicolonKeyword_5_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__Group_5_2__1__Impl"


    // $ANTLR start "rule__Attribute__Group__0"
    // InternalSimple.g:956:1: rule__Attribute__Group__0 : rule__Attribute__Group__0__Impl rule__Attribute__Group__1 ;
    public final void rule__Attribute__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:960:1: ( rule__Attribute__Group__0__Impl rule__Attribute__Group__1 )
            // InternalSimple.g:961:2: rule__Attribute__Group__0__Impl rule__Attribute__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__Attribute__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Attribute__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__0"


    // $ANTLR start "rule__Attribute__Group__0__Impl"
    // InternalSimple.g:968:1: rule__Attribute__Group__0__Impl : ( () ) ;
    public final void rule__Attribute__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:972:1: ( ( () ) )
            // InternalSimple.g:973:1: ( () )
            {
            // InternalSimple.g:973:1: ( () )
            // InternalSimple.g:974:2: ()
            {
             before(grammarAccess.getAttributeAccess().getAttributeAction_0()); 
            // InternalSimple.g:975:2: ()
            // InternalSimple.g:975:3: 
            {
            }

             after(grammarAccess.getAttributeAccess().getAttributeAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__0__Impl"


    // $ANTLR start "rule__Attribute__Group__1"
    // InternalSimple.g:983:1: rule__Attribute__Group__1 : rule__Attribute__Group__1__Impl rule__Attribute__Group__2 ;
    public final void rule__Attribute__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:987:1: ( rule__Attribute__Group__1__Impl rule__Attribute__Group__2 )
            // InternalSimple.g:988:2: rule__Attribute__Group__1__Impl rule__Attribute__Group__2
            {
            pushFollow(FOLLOW_12);
            rule__Attribute__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Attribute__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__1"


    // $ANTLR start "rule__Attribute__Group__1__Impl"
    // InternalSimple.g:995:1: rule__Attribute__Group__1__Impl : ( ( rule__Attribute__VisibilityAssignment_1 )? ) ;
    public final void rule__Attribute__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:999:1: ( ( ( rule__Attribute__VisibilityAssignment_1 )? ) )
            // InternalSimple.g:1000:1: ( ( rule__Attribute__VisibilityAssignment_1 )? )
            {
            // InternalSimple.g:1000:1: ( ( rule__Attribute__VisibilityAssignment_1 )? )
            // InternalSimple.g:1001:2: ( rule__Attribute__VisibilityAssignment_1 )?
            {
             before(grammarAccess.getAttributeAccess().getVisibilityAssignment_1()); 
            // InternalSimple.g:1002:2: ( rule__Attribute__VisibilityAssignment_1 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( ((LA13_0>=11 && LA13_0<=12)) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalSimple.g:1002:3: rule__Attribute__VisibilityAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Attribute__VisibilityAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getAttributeAccess().getVisibilityAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__1__Impl"


    // $ANTLR start "rule__Attribute__Group__2"
    // InternalSimple.g:1010:1: rule__Attribute__Group__2 : rule__Attribute__Group__2__Impl rule__Attribute__Group__3 ;
    public final void rule__Attribute__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1014:1: ( rule__Attribute__Group__2__Impl rule__Attribute__Group__3 )
            // InternalSimple.g:1015:2: rule__Attribute__Group__2__Impl rule__Attribute__Group__3
            {
            pushFollow(FOLLOW_14);
            rule__Attribute__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Attribute__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__2"


    // $ANTLR start "rule__Attribute__Group__2__Impl"
    // InternalSimple.g:1022:1: rule__Attribute__Group__2__Impl : ( ( rule__Attribute__CardinalityAssignment_2 ) ) ;
    public final void rule__Attribute__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1026:1: ( ( ( rule__Attribute__CardinalityAssignment_2 ) ) )
            // InternalSimple.g:1027:1: ( ( rule__Attribute__CardinalityAssignment_2 ) )
            {
            // InternalSimple.g:1027:1: ( ( rule__Attribute__CardinalityAssignment_2 ) )
            // InternalSimple.g:1028:2: ( rule__Attribute__CardinalityAssignment_2 )
            {
             before(grammarAccess.getAttributeAccess().getCardinalityAssignment_2()); 
            // InternalSimple.g:1029:2: ( rule__Attribute__CardinalityAssignment_2 )
            // InternalSimple.g:1029:3: rule__Attribute__CardinalityAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Attribute__CardinalityAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getAttributeAccess().getCardinalityAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__2__Impl"


    // $ANTLR start "rule__Attribute__Group__3"
    // InternalSimple.g:1037:1: rule__Attribute__Group__3 : rule__Attribute__Group__3__Impl rule__Attribute__Group__4 ;
    public final void rule__Attribute__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1041:1: ( rule__Attribute__Group__3__Impl rule__Attribute__Group__4 )
            // InternalSimple.g:1042:2: rule__Attribute__Group__3__Impl rule__Attribute__Group__4
            {
            pushFollow(FOLLOW_5);
            rule__Attribute__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Attribute__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__3"


    // $ANTLR start "rule__Attribute__Group__3__Impl"
    // InternalSimple.g:1049:1: rule__Attribute__Group__3__Impl : ( ( rule__Attribute__TypeAssignment_3 ) ) ;
    public final void rule__Attribute__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1053:1: ( ( ( rule__Attribute__TypeAssignment_3 ) ) )
            // InternalSimple.g:1054:1: ( ( rule__Attribute__TypeAssignment_3 ) )
            {
            // InternalSimple.g:1054:1: ( ( rule__Attribute__TypeAssignment_3 ) )
            // InternalSimple.g:1055:2: ( rule__Attribute__TypeAssignment_3 )
            {
             before(grammarAccess.getAttributeAccess().getTypeAssignment_3()); 
            // InternalSimple.g:1056:2: ( rule__Attribute__TypeAssignment_3 )
            // InternalSimple.g:1056:3: rule__Attribute__TypeAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Attribute__TypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getAttributeAccess().getTypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__3__Impl"


    // $ANTLR start "rule__Attribute__Group__4"
    // InternalSimple.g:1064:1: rule__Attribute__Group__4 : rule__Attribute__Group__4__Impl ;
    public final void rule__Attribute__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1068:1: ( rule__Attribute__Group__4__Impl )
            // InternalSimple.g:1069:2: rule__Attribute__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Attribute__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__4"


    // $ANTLR start "rule__Attribute__Group__4__Impl"
    // InternalSimple.g:1075:1: rule__Attribute__Group__4__Impl : ( ( rule__Attribute__NameAssignment_4 ) ) ;
    public final void rule__Attribute__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1079:1: ( ( ( rule__Attribute__NameAssignment_4 ) ) )
            // InternalSimple.g:1080:1: ( ( rule__Attribute__NameAssignment_4 ) )
            {
            // InternalSimple.g:1080:1: ( ( rule__Attribute__NameAssignment_4 ) )
            // InternalSimple.g:1081:2: ( rule__Attribute__NameAssignment_4 )
            {
             before(grammarAccess.getAttributeAccess().getNameAssignment_4()); 
            // InternalSimple.g:1082:2: ( rule__Attribute__NameAssignment_4 )
            // InternalSimple.g:1082:3: rule__Attribute__NameAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Attribute__NameAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getAttributeAccess().getNameAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__Group__4__Impl"


    // $ANTLR start "rule__Reference__Group__0"
    // InternalSimple.g:1091:1: rule__Reference__Group__0 : rule__Reference__Group__0__Impl rule__Reference__Group__1 ;
    public final void rule__Reference__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1095:1: ( rule__Reference__Group__0__Impl rule__Reference__Group__1 )
            // InternalSimple.g:1096:2: rule__Reference__Group__0__Impl rule__Reference__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__Reference__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Reference__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__0"


    // $ANTLR start "rule__Reference__Group__0__Impl"
    // InternalSimple.g:1103:1: rule__Reference__Group__0__Impl : ( () ) ;
    public final void rule__Reference__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1107:1: ( ( () ) )
            // InternalSimple.g:1108:1: ( () )
            {
            // InternalSimple.g:1108:1: ( () )
            // InternalSimple.g:1109:2: ()
            {
             before(grammarAccess.getReferenceAccess().getReferenceAction_0()); 
            // InternalSimple.g:1110:2: ()
            // InternalSimple.g:1110:3: 
            {
            }

             after(grammarAccess.getReferenceAccess().getReferenceAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__0__Impl"


    // $ANTLR start "rule__Reference__Group__1"
    // InternalSimple.g:1118:1: rule__Reference__Group__1 : rule__Reference__Group__1__Impl rule__Reference__Group__2 ;
    public final void rule__Reference__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1122:1: ( rule__Reference__Group__1__Impl rule__Reference__Group__2 )
            // InternalSimple.g:1123:2: rule__Reference__Group__1__Impl rule__Reference__Group__2
            {
            pushFollow(FOLLOW_12);
            rule__Reference__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Reference__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__1"


    // $ANTLR start "rule__Reference__Group__1__Impl"
    // InternalSimple.g:1130:1: rule__Reference__Group__1__Impl : ( ( rule__Reference__VisibilityAssignment_1 )? ) ;
    public final void rule__Reference__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1134:1: ( ( ( rule__Reference__VisibilityAssignment_1 )? ) )
            // InternalSimple.g:1135:1: ( ( rule__Reference__VisibilityAssignment_1 )? )
            {
            // InternalSimple.g:1135:1: ( ( rule__Reference__VisibilityAssignment_1 )? )
            // InternalSimple.g:1136:2: ( rule__Reference__VisibilityAssignment_1 )?
            {
             before(grammarAccess.getReferenceAccess().getVisibilityAssignment_1()); 
            // InternalSimple.g:1137:2: ( rule__Reference__VisibilityAssignment_1 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( ((LA14_0>=11 && LA14_0<=12)) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalSimple.g:1137:3: rule__Reference__VisibilityAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Reference__VisibilityAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getReferenceAccess().getVisibilityAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__1__Impl"


    // $ANTLR start "rule__Reference__Group__2"
    // InternalSimple.g:1145:1: rule__Reference__Group__2 : rule__Reference__Group__2__Impl rule__Reference__Group__3 ;
    public final void rule__Reference__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1149:1: ( rule__Reference__Group__2__Impl rule__Reference__Group__3 )
            // InternalSimple.g:1150:2: rule__Reference__Group__2__Impl rule__Reference__Group__3
            {
            pushFollow(FOLLOW_15);
            rule__Reference__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Reference__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__2"


    // $ANTLR start "rule__Reference__Group__2__Impl"
    // InternalSimple.g:1157:1: rule__Reference__Group__2__Impl : ( ( rule__Reference__CardinalityAssignment_2 ) ) ;
    public final void rule__Reference__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1161:1: ( ( ( rule__Reference__CardinalityAssignment_2 ) ) )
            // InternalSimple.g:1162:1: ( ( rule__Reference__CardinalityAssignment_2 ) )
            {
            // InternalSimple.g:1162:1: ( ( rule__Reference__CardinalityAssignment_2 ) )
            // InternalSimple.g:1163:2: ( rule__Reference__CardinalityAssignment_2 )
            {
             before(grammarAccess.getReferenceAccess().getCardinalityAssignment_2()); 
            // InternalSimple.g:1164:2: ( rule__Reference__CardinalityAssignment_2 )
            // InternalSimple.g:1164:3: rule__Reference__CardinalityAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Reference__CardinalityAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getReferenceAccess().getCardinalityAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__2__Impl"


    // $ANTLR start "rule__Reference__Group__3"
    // InternalSimple.g:1172:1: rule__Reference__Group__3 : rule__Reference__Group__3__Impl rule__Reference__Group__4 ;
    public final void rule__Reference__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1176:1: ( rule__Reference__Group__3__Impl rule__Reference__Group__4 )
            // InternalSimple.g:1177:2: rule__Reference__Group__3__Impl rule__Reference__Group__4
            {
            pushFollow(FOLLOW_5);
            rule__Reference__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Reference__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__3"


    // $ANTLR start "rule__Reference__Group__3__Impl"
    // InternalSimple.g:1184:1: rule__Reference__Group__3__Impl : ( ( rule__Reference__TypeAssignment_3 ) ) ;
    public final void rule__Reference__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1188:1: ( ( ( rule__Reference__TypeAssignment_3 ) ) )
            // InternalSimple.g:1189:1: ( ( rule__Reference__TypeAssignment_3 ) )
            {
            // InternalSimple.g:1189:1: ( ( rule__Reference__TypeAssignment_3 ) )
            // InternalSimple.g:1190:2: ( rule__Reference__TypeAssignment_3 )
            {
             before(grammarAccess.getReferenceAccess().getTypeAssignment_3()); 
            // InternalSimple.g:1191:2: ( rule__Reference__TypeAssignment_3 )
            // InternalSimple.g:1191:3: rule__Reference__TypeAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Reference__TypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getReferenceAccess().getTypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__3__Impl"


    // $ANTLR start "rule__Reference__Group__4"
    // InternalSimple.g:1199:1: rule__Reference__Group__4 : rule__Reference__Group__4__Impl ;
    public final void rule__Reference__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1203:1: ( rule__Reference__Group__4__Impl )
            // InternalSimple.g:1204:2: rule__Reference__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Reference__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__4"


    // $ANTLR start "rule__Reference__Group__4__Impl"
    // InternalSimple.g:1210:1: rule__Reference__Group__4__Impl : ( ( rule__Reference__NameAssignment_4 ) ) ;
    public final void rule__Reference__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1214:1: ( ( ( rule__Reference__NameAssignment_4 ) ) )
            // InternalSimple.g:1215:1: ( ( rule__Reference__NameAssignment_4 ) )
            {
            // InternalSimple.g:1215:1: ( ( rule__Reference__NameAssignment_4 ) )
            // InternalSimple.g:1216:2: ( rule__Reference__NameAssignment_4 )
            {
             before(grammarAccess.getReferenceAccess().getNameAssignment_4()); 
            // InternalSimple.g:1217:2: ( rule__Reference__NameAssignment_4 )
            // InternalSimple.g:1217:3: rule__Reference__NameAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Reference__NameAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getReferenceAccess().getNameAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__Group__4__Impl"


    // $ANTLR start "rule__Program__PackagesAssignment_1"
    // InternalSimple.g:1226:1: rule__Program__PackagesAssignment_1 : ( rulePackage ) ;
    public final void rule__Program__PackagesAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1230:1: ( ( rulePackage ) )
            // InternalSimple.g:1231:2: ( rulePackage )
            {
            // InternalSimple.g:1231:2: ( rulePackage )
            // InternalSimple.g:1232:3: rulePackage
            {
             before(grammarAccess.getProgramAccess().getPackagesPackageParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            rulePackage();

            state._fsp--;

             after(grammarAccess.getProgramAccess().getPackagesPackageParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Program__PackagesAssignment_1"


    // $ANTLR start "rule__Package__NameAssignment_2"
    // InternalSimple.g:1241:1: rule__Package__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__Package__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1245:1: ( ( ruleEString ) )
            // InternalSimple.g:1246:2: ( ruleEString )
            {
            // InternalSimple.g:1246:2: ( ruleEString )
            // InternalSimple.g:1247:3: ruleEString
            {
             before(grammarAccess.getPackageAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getPackageAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__NameAssignment_2"


    // $ANTLR start "rule__Package__PackagesAssignment_4_0"
    // InternalSimple.g:1256:1: rule__Package__PackagesAssignment_4_0 : ( rulePackage ) ;
    public final void rule__Package__PackagesAssignment_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1260:1: ( ( rulePackage ) )
            // InternalSimple.g:1261:2: ( rulePackage )
            {
            // InternalSimple.g:1261:2: ( rulePackage )
            // InternalSimple.g:1262:3: rulePackage
            {
             before(grammarAccess.getPackageAccess().getPackagesPackageParserRuleCall_4_0_0()); 
            pushFollow(FOLLOW_2);
            rulePackage();

            state._fsp--;

             after(grammarAccess.getPackageAccess().getPackagesPackageParserRuleCall_4_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__PackagesAssignment_4_0"


    // $ANTLR start "rule__Package__ClassesAssignment_4_1"
    // InternalSimple.g:1271:1: rule__Package__ClassesAssignment_4_1 : ( ruleClass ) ;
    public final void rule__Package__ClassesAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1275:1: ( ( ruleClass ) )
            // InternalSimple.g:1276:2: ( ruleClass )
            {
            // InternalSimple.g:1276:2: ( ruleClass )
            // InternalSimple.g:1277:3: ruleClass
            {
             before(grammarAccess.getPackageAccess().getClassesClassParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleClass();

            state._fsp--;

             after(grammarAccess.getPackageAccess().getClassesClassParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Package__ClassesAssignment_4_1"


    // $ANTLR start "rule__Class__VisibilityAssignment_1"
    // InternalSimple.g:1286:1: rule__Class__VisibilityAssignment_1 : ( ruleVisibility ) ;
    public final void rule__Class__VisibilityAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1290:1: ( ( ruleVisibility ) )
            // InternalSimple.g:1291:2: ( ruleVisibility )
            {
            // InternalSimple.g:1291:2: ( ruleVisibility )
            // InternalSimple.g:1292:3: ruleVisibility
            {
             before(grammarAccess.getClassAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getClassAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__VisibilityAssignment_1"


    // $ANTLR start "rule__Class__NameAssignment_3"
    // InternalSimple.g:1301:1: rule__Class__NameAssignment_3 : ( ruleEString ) ;
    public final void rule__Class__NameAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1305:1: ( ( ruleEString ) )
            // InternalSimple.g:1306:2: ( ruleEString )
            {
            // InternalSimple.g:1306:2: ( ruleEString )
            // InternalSimple.g:1307:3: ruleEString
            {
             before(grammarAccess.getClassAccess().getNameEStringParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getClassAccess().getNameEStringParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__NameAssignment_3"


    // $ANTLR start "rule__Class__AttributesAssignment_5_0_0"
    // InternalSimple.g:1316:1: rule__Class__AttributesAssignment_5_0_0 : ( ruleAttribute ) ;
    public final void rule__Class__AttributesAssignment_5_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1320:1: ( ( ruleAttribute ) )
            // InternalSimple.g:1321:2: ( ruleAttribute )
            {
            // InternalSimple.g:1321:2: ( ruleAttribute )
            // InternalSimple.g:1322:3: ruleAttribute
            {
             before(grammarAccess.getClassAccess().getAttributesAttributeParserRuleCall_5_0_0_0()); 
            pushFollow(FOLLOW_2);
            ruleAttribute();

            state._fsp--;

             after(grammarAccess.getClassAccess().getAttributesAttributeParserRuleCall_5_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__AttributesAssignment_5_0_0"


    // $ANTLR start "rule__Class__ReferencesAssignment_5_0_1"
    // InternalSimple.g:1331:1: rule__Class__ReferencesAssignment_5_0_1 : ( ruleReference ) ;
    public final void rule__Class__ReferencesAssignment_5_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1335:1: ( ( ruleReference ) )
            // InternalSimple.g:1336:2: ( ruleReference )
            {
            // InternalSimple.g:1336:2: ( ruleReference )
            // InternalSimple.g:1337:3: ruleReference
            {
             before(grammarAccess.getClassAccess().getReferencesReferenceParserRuleCall_5_0_1_0()); 
            pushFollow(FOLLOW_2);
            ruleReference();

            state._fsp--;

             after(grammarAccess.getClassAccess().getReferencesReferenceParserRuleCall_5_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__ReferencesAssignment_5_0_1"


    // $ANTLR start "rule__Class__AttributesAssignment_5_2_0_0"
    // InternalSimple.g:1346:1: rule__Class__AttributesAssignment_5_2_0_0 : ( ruleAttribute ) ;
    public final void rule__Class__AttributesAssignment_5_2_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1350:1: ( ( ruleAttribute ) )
            // InternalSimple.g:1351:2: ( ruleAttribute )
            {
            // InternalSimple.g:1351:2: ( ruleAttribute )
            // InternalSimple.g:1352:3: ruleAttribute
            {
             before(grammarAccess.getClassAccess().getAttributesAttributeParserRuleCall_5_2_0_0_0()); 
            pushFollow(FOLLOW_2);
            ruleAttribute();

            state._fsp--;

             after(grammarAccess.getClassAccess().getAttributesAttributeParserRuleCall_5_2_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__AttributesAssignment_5_2_0_0"


    // $ANTLR start "rule__Class__ReferencesAssignment_5_2_0_1"
    // InternalSimple.g:1361:1: rule__Class__ReferencesAssignment_5_2_0_1 : ( ruleReference ) ;
    public final void rule__Class__ReferencesAssignment_5_2_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1365:1: ( ( ruleReference ) )
            // InternalSimple.g:1366:2: ( ruleReference )
            {
            // InternalSimple.g:1366:2: ( ruleReference )
            // InternalSimple.g:1367:3: ruleReference
            {
             before(grammarAccess.getClassAccess().getReferencesReferenceParserRuleCall_5_2_0_1_0()); 
            pushFollow(FOLLOW_2);
            ruleReference();

            state._fsp--;

             after(grammarAccess.getClassAccess().getReferencesReferenceParserRuleCall_5_2_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Class__ReferencesAssignment_5_2_0_1"


    // $ANTLR start "rule__Attribute__VisibilityAssignment_1"
    // InternalSimple.g:1376:1: rule__Attribute__VisibilityAssignment_1 : ( ruleVisibility ) ;
    public final void rule__Attribute__VisibilityAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1380:1: ( ( ruleVisibility ) )
            // InternalSimple.g:1381:2: ( ruleVisibility )
            {
            // InternalSimple.g:1381:2: ( ruleVisibility )
            // InternalSimple.g:1382:3: ruleVisibility
            {
             before(grammarAccess.getAttributeAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getAttributeAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__VisibilityAssignment_1"


    // $ANTLR start "rule__Attribute__CardinalityAssignment_2"
    // InternalSimple.g:1391:1: rule__Attribute__CardinalityAssignment_2 : ( ruleCardinality ) ;
    public final void rule__Attribute__CardinalityAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1395:1: ( ( ruleCardinality ) )
            // InternalSimple.g:1396:2: ( ruleCardinality )
            {
            // InternalSimple.g:1396:2: ( ruleCardinality )
            // InternalSimple.g:1397:3: ruleCardinality
            {
             before(grammarAccess.getAttributeAccess().getCardinalityCardinalityEnumRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleCardinality();

            state._fsp--;

             after(grammarAccess.getAttributeAccess().getCardinalityCardinalityEnumRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__CardinalityAssignment_2"


    // $ANTLR start "rule__Attribute__TypeAssignment_3"
    // InternalSimple.g:1406:1: rule__Attribute__TypeAssignment_3 : ( ruleType ) ;
    public final void rule__Attribute__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1410:1: ( ( ruleType ) )
            // InternalSimple.g:1411:2: ( ruleType )
            {
            // InternalSimple.g:1411:2: ( ruleType )
            // InternalSimple.g:1412:3: ruleType
            {
             before(grammarAccess.getAttributeAccess().getTypeTypeEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleType();

            state._fsp--;

             after(grammarAccess.getAttributeAccess().getTypeTypeEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__TypeAssignment_3"


    // $ANTLR start "rule__Attribute__NameAssignment_4"
    // InternalSimple.g:1421:1: rule__Attribute__NameAssignment_4 : ( ruleEString ) ;
    public final void rule__Attribute__NameAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1425:1: ( ( ruleEString ) )
            // InternalSimple.g:1426:2: ( ruleEString )
            {
            // InternalSimple.g:1426:2: ( ruleEString )
            // InternalSimple.g:1427:3: ruleEString
            {
             before(grammarAccess.getAttributeAccess().getNameEStringParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getAttributeAccess().getNameEStringParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attribute__NameAssignment_4"


    // $ANTLR start "rule__Reference__VisibilityAssignment_1"
    // InternalSimple.g:1436:1: rule__Reference__VisibilityAssignment_1 : ( ruleVisibility ) ;
    public final void rule__Reference__VisibilityAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1440:1: ( ( ruleVisibility ) )
            // InternalSimple.g:1441:2: ( ruleVisibility )
            {
            // InternalSimple.g:1441:2: ( ruleVisibility )
            // InternalSimple.g:1442:3: ruleVisibility
            {
             before(grammarAccess.getReferenceAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getReferenceAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__VisibilityAssignment_1"


    // $ANTLR start "rule__Reference__CardinalityAssignment_2"
    // InternalSimple.g:1451:1: rule__Reference__CardinalityAssignment_2 : ( ruleCardinality ) ;
    public final void rule__Reference__CardinalityAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1455:1: ( ( ruleCardinality ) )
            // InternalSimple.g:1456:2: ( ruleCardinality )
            {
            // InternalSimple.g:1456:2: ( ruleCardinality )
            // InternalSimple.g:1457:3: ruleCardinality
            {
             before(grammarAccess.getReferenceAccess().getCardinalityCardinalityEnumRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleCardinality();

            state._fsp--;

             after(grammarAccess.getReferenceAccess().getCardinalityCardinalityEnumRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__CardinalityAssignment_2"


    // $ANTLR start "rule__Reference__TypeAssignment_3"
    // InternalSimple.g:1466:1: rule__Reference__TypeAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__Reference__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1470:1: ( ( ( RULE_ID ) ) )
            // InternalSimple.g:1471:2: ( ( RULE_ID ) )
            {
            // InternalSimple.g:1471:2: ( ( RULE_ID ) )
            // InternalSimple.g:1472:3: ( RULE_ID )
            {
             before(grammarAccess.getReferenceAccess().getTypeClassCrossReference_3_0()); 
            // InternalSimple.g:1473:3: ( RULE_ID )
            // InternalSimple.g:1474:4: RULE_ID
            {
             before(grammarAccess.getReferenceAccess().getTypeClassIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getReferenceAccess().getTypeClassIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getReferenceAccess().getTypeClassCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__TypeAssignment_3"


    // $ANTLR start "rule__Reference__NameAssignment_4"
    // InternalSimple.g:1485:1: rule__Reference__NameAssignment_4 : ( ruleEString ) ;
    public final void rule__Reference__NameAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimple.g:1489:1: ( ( ruleEString ) )
            // InternalSimple.g:1490:2: ( ruleEString )
            {
            // InternalSimple.g:1490:2: ( ruleEString )
            // InternalSimple.g:1491:3: ruleEString
            {
             before(grammarAccess.getReferenceAccess().getNameEStringParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getReferenceAccess().getNameEStringParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Reference__NameAssignment_4"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000681800L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000481802L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000481800L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000271800L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000071800L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000071802L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x000000000000E000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000020L});

}