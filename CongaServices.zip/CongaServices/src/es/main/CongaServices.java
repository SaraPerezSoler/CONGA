package es.main;

import java.io.File;

import javax.servlet.ServletContext;


public class CongaServices {

	private static String FOLDER_PATH = null;
	private String path;
	private File file;
	//private static ResourceSet
	
	public CongaServices(ServletContext context, File file, String botName) {
		if (FOLDER_PATH == null) {
			FOLDER_PATH = context.getInitParameter("ServicePath");
			File file1 = new File(FOLDER_PATH);
			if (!file1.exists()) {
				file1.mkdirs();
			}
		}
		String countString = "";
		int count = 0;
		File file2 = null;
		do {
			path = FOLDER_PATH + File.separator + botName + countString + ".bot";
			file2 = new File(path);
			count++;
			countString = Integer.toString(count);
		} while (file2.exists());
		file.renameTo(file2);
		this.file = file;
	}

	public void destroy() {
		if (file.exists()) {
			file.delete();
		}
	}

}
