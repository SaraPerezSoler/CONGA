package es.services;

import java.io.File;
import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.multipart.FormDataParam;

import es.main.CongaServices;

@Path("/dialogflow")
public class Dialogflow {

	@POST
	@Path("/generator")
	@Consumes (MediaType.MULTIPART_FORM_DATA)
	//@Produces (MediaType.APPLICATION_OCTET_STREAM)
	public String generator (@Context ServletContext context, @FormDataParam("file") File file, @FormDataParam("botName") String botName) {
		CongaServices cs = new CongaServices(context, file, botName);
		
		return "Subido con exito!!";
		//cs.destroy();
		
	}
}
